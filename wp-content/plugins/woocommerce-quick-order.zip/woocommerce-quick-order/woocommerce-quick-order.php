<?php
/**
 * Plugin Name: WooCommerce Quick Order
 * Plugin URI: http://codup.io/
 * Description: Allows the user to add quick products in order
 * Version: 1.2.1.6
 * Author: Codup
 * Author URI: http://codup.io/
 * Text Domain: woocommerce-quick-order
 * Domain Path: /languages
 * Developer: Codup
 * Developer URI: http://codup.io/
 * Woo: 4891278:d87835e671dc48be084f55081f2904f3
 * WC requires at least: 3.8.0
 * WC tested up to: 5.5.1
 *
 * Copyright: Â© 2009-2019 WooCommerce.
 * License: GNU General Public License v3.0
 * License URI: http://www.gnu.org/licenses/gpl-3.0.html
 *
 * @package B2B_Quick_Order/templates
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Required functions
 */
if ( ! function_exists( 'is_woocommerce_active' ) ) {
		require_once dirname( __FILE__ ) . '/woo-includes/woo-functions.php';
}

register_activation_hook( __FILE__, 'wqbo_check_dependencies' );


/**
 * Check dependencies for plugin.
 */
function wqbo_check_dependencies() {

	if ( ! is_woocommerce_active() ) {
				// Deactivate the plugin.
				deactivate_plugins( __FILE__ );
		?>
				<?php esc_attr_e( 'In order to activate this plugin please make sure to install and activate the following plugin(s)', 'woocommerce-quick-order' ); ?>:<ol style="margin-top: 4px;margin-bottom: 0;font-size: 14px;"><li>WooCommerce</li></ol>

						<?php
						// Throw an error in the WordPress admin console.
						die();
	} else {
		wqbo_admin_notice_activation_hook();
	}
}

/**
 * Runs only when the plugin is activated.
 */
function wqbo_admin_notice_activation_hook() {
	/* Create transient data */
	set_transient( 'wqbo-admin-notice', true, 20 );
}

register_deactivation_hook( __FILE__, 'wqbo_delete_transient' );

/**
 * Runs only when the plugin is activated.
 */
function wqbo_delete_transient() {
	/* Delete transient, only display this notice once. */
	delete_transient( 'wqbo-admin-notice' );
}

add_action( 'admin_notices', 'wqbo_admin_notice' );

/**
 * Admin Notice on Activation.
 */
function wqbo_admin_notice() {

	/* Check transient, if available display notice */
	if ( get_transient( 'wqbo-admin-notice' ) ) {
		?>
		<div  class="updated notice is-dismissible">
			<p style="font-size: 15px;">
			<?php
			/* translators: 1: plugin name 2: line break */ echo sprintf( esc_attr__( 'Thank you for using %1$s. %2$s Plugin has been activated and copy this short code [wqbo_quick_order] to any page for the visibility of table.', 'woocommerce-quick-order' ), '<b>WooCommerce Quick Order</b>', '<br>' );
			?>
			</p>
		</div>
		<?php
	}
}

if ( is_woocommerce_active() ) {

	if ( ! defined( 'WQBO_PLUGIN_FILE' ) ) {
		define( 'WQBO_PLUGIN_FILE', __FILE__ );
	}

	if ( ! defined( 'WQBO_PLUGIN_URL' ) ) {
		define( 'WQBO_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
	}

	if ( ! defined( 'WQBO_ABSPATH' ) ) {
		define( 'WQBO_ABSPATH', dirname( __FILE__ ) );
	}

	if ( ! defined( 'WQBO_TEMP_DIR' ) ) {
		define( 'WQBO_TEMP_DIR', WQBO_ABSPATH . '/templates' );
	}

	include_once WQBO_ABSPATH . '/helpers.php';
	include_once WQBO_ABSPATH . '/includes/class-wqbo-loader.php';
	require_once WQBO_ABSPATH . '/contact_us/class-wqbo-contact-us.php';

}

