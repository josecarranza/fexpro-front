<?php
/**
 * Quick Order Function Class.
 *
 * @package Woocommerce Quick Order.
 */

/**
 * Functions used by plugins
 */
if ( ! class_exists( 'WC_Dependencies' ) ) {
	require_once dirname( __FILE__ ) . '/class-wc-dependencies.php';
}

/**
 * WC Detection
 */
if ( ! function_exists( 'is_woocommerce_active' ) ) {
	/**
	 * Is wocommerce Active.
	 */
	function is_woocommerce_active() {
		return WC_Dependencies::woocommerce_active_check();
	}
}
