jQuery( document ).ready(
	function(){
		jQuery( ".selectwoo" ).select2(
			{
				closeOnSelect : false,
				placeholder : "Select Category",
				allowHtml: true,
				allowClear: true,
				tags: false
			}
		);
	}
)

jQuery( document ).on(
	"click",
	".delete_shortcode",
	function() {
		var r = confirm( "Are you sure you want to remove this shortcode !" );
		if (r) {
			window.location = jQuery( ".admin_url" ).val() + 'admin.php?page=wqbo-quick-order-settings&action=delete&shortcodeid=' + jQuery( this ).attr( 'data-id' );
		} else {
			alert( ' Your shortcode is saved.' );
		}
	}
)
