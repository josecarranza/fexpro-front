/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/*
	By Osvaldas Valutis, www.osvaldas.info
	Available for use under the MIT License
*/
(function(e,t,n){var r = e.querySelectorAll( "html" )[0];r.className = r.className.replace( /(^|\s)no-js(\s|$)/,"$1js$2" )})( document,window,0 );

( function ( document, window, index )
{
	var inputs = document.querySelectorAll( '.inputfile' );
	Array.prototype.forEach.call(
		inputs,
		function( input )
		{
			var label	 = input.nextElementSibling,
				labelVal = label.innerHTML;

			input.addEventListener(
				'change',
				function( e )
				{
					var fileName = '';
					if ( this.files && this.files.length > 1 ) {
						fileName = ( this.getAttribute( 'data-multiple-caption' ) || '' ).replace( '{count}', this.files.length );
					} else {
						fileName = e.target.value.split( '\\' ).pop();
					}

					if ( fileName ) {
						label.querySelector( 'span' ).innerHTML = fileName;
					} else {
						label.innerHTML = labelVal;
					}
				}
			);

			// Firefox bug fix
			input.addEventListener( 'focus', function(){ input.classList.add( 'has-focus' ); } );
			input.addEventListener( 'blur', function(){ input.classList.remove( 'has-focus' ); } );
		}
	);
}( document, window, 0 ));


function decode(str) {
	return str.replace(
		/&#(\d+);/g,
		function (match, dec) {
			return String.fromCharCode( dec );
		}
	);
}

function clearForm() {
	jQuery( '.wqbo-price' ).html( '' );
	var img = jQuery( '.wqbo-thumb img' ).attr( 'date-src' );
	jQuery( '.wqbo-thumb img' ).attr( 'src', img );
	jQuery( 'input[name=wqbo_product]' ).val( '' );
	jQuery( 'input[name=wqbo_quantity]' ).val( '' );
	jQuery( 'input[name=wqbo_product]' ).attr( 'data-product', '' );
}

function fetchThumbnail(product) {
	var data = {
		'action': 'wqo_fetch_product_image',
		'product': product
	};
	jQuery.post(
		ajax_object.ajax_url,
		data,
		function (response) {
			jQuery( '.wqbo-thumb img' ).attr( 'src', response );
		}
	);
}

function addToBucket() {
	var data = {
		'action': 'wqo_add_product_in_bucket',
		'wqbo_product': jQuery( 'input[name=wqbo_product]' ).attr( 'data-product' ),
		'wqbo_codeid': jQuery( 'input[name=wqbo_product]' ).attr( 'data-codeid' ),
		'wqbo_quantity': jQuery( 'input[name=wqbo_quantity]' ).val(),
		'block_settings': jQuery( 'input[name=block_settings]' ).val(),
		'wqbo_url': jQuery( 'input[name=wqbo_product]' ).attr( 'data-url' ),
		'_wpnonce': jQuery( 'input[name=_wpnonce]' ).val(),
	};

	jQuery.post(
		ajax_object.ajax_url,
		data,
		function (response) {
			jQuery( this ).submit();
			clearForm();
			jQuery( '.wqbo-bucket' ).html( response.data );
		}
	);
}

function showPopup(obj) {
	tb_show( "HAI","#TB_inline?height=400&amp;width=500&amp;inlineId=" + jQuery( obj ).data( 'id' ) + "&amp;modal=true",null );
}

function closePopup() {
	tb_remove();
}


jQuery( document ).ready(
	function () {

		jQuery( '#wqbo_product_suggest' ).keyup(
			function () {
				if (jQuery( this ).val() == '') {
					clearForm();
				}
			}
		);

		var searchRequest;
		var obj = jQuery( '#wqbo_product_suggest' );
		obj.autocomplete(
			{
				minChars: 2,
				source: function (term, suggest) {
					try {
						searchRequest.abort();
					} catch (e) {
					}
					searchRequest = jQuery.post(
						ajax_object.ajax_url,
						{
							search: term,
							_wpnonce: jQuery( 'input[name=_wpnonce]' ).val(),
							wqbo_codeid: jQuery( 'input[name=wqbo_product]' ).attr( 'data-codeid' ),
							block_settings: jQuery( 'input[name=block_settings]' ).val(),
							action: 'wqo_product_search'
						},
						function (res) {
							suggest( res.data );
						}
					);
				},
				focus: function (event, ui) {
					event.preventDefault();
					jQuery( this ).val( decode( ui.item.label ) );
					jQuery( this ).attr( 'data-product', ui.item.value );
				},
				select: function (event, ui) {
					event.preventDefault();
					if (ui.item.value != 'No Results Found') {
						jQuery( this ).val( decode( ui.item.label ) );
						jQuery( this ).attr( 'data-product', ui.item.value );
						jQuery( 'input[name=wqbo_quantity]' ).focus();
						jQuery( 'input[name=wqbo_quantity]' ).val( '1' );
						jQuery( 'input[name=wqbo_quantity]' ).trigger( 'change' );
						fetchThumbnail( ui.item.value );
					}
				}
			}
		);

		obj.data( "ui-autocomplete" )._renderItem = function (ul, item) {

			var $li  = jQuery( '<li>' ),
				$img = jQuery( '<img style="width:30px">' );

			$img.attr(
				{
					src: item.icon,
					alt: item.label
				}
			);

			$li.attr( 'data-value', item.label );
			$li.append( '<a href="#">' );
			$li.find( 'a' ).append( $img ).append( item.label );

			return $li.appendTo( ul );
		};

		jQuery( document ).on(
			'click',
			'.wqbo_add_to_cart',
			function () {
				var data = {
					'action': 'wqo_add_products_in_cart',
					'wqbo_codeid': jQuery( 'input[name=wqbo_product]' ).attr( 'data-codeid' ),
				};
				jQuery.post(
					ajax_object.ajax_url,
					data,
					function (response) {
						if (response == 'success') {
							window.location = window.location.href;
						}
					}
				);
			}
		);

		jQuery( document ).on(
			'click',
			'.wqbo_add_to_rfq',
			function () {
				var data = {
					'action': 'wqo_add_products_in_rfq',
					'wqbo_codeid': jQuery( 'input[name=wqbo_product]' ).attr( 'data-codeid' ),
				};
				jQuery.post(
					ajax_object.ajax_url,
					data,
					function (response) {
						if (response == 'success') {
							window.location = window.location.href;
						}
					}
				);
			}
		);

		jQuery( "#wqbo-csv-order-form" ).submit(
			function (e) {
				e.preventDefault();
				var form_data = new FormData( this )

				form_data.append( 'wqbo_codeid', jQuery( 'input[name=wqbo_product]' ).attr( 'data-codeid' ) );
				form_data.append( 'wqbo_url', jQuery( 'input[name=wqbo_product]' ).attr( 'data-url' ) );
				form_data.append( 'block_settings', jQuery( 'input[name=block_settings]' ).val() );
				form_data.append( 'action', 'wqo_add_csv_product_in_bucket' );

				jQuery.ajax(
					{
						url: ajax_object.ajax_url,
						type: 'post',
						contentType: false,
						processData: false,
						data: form_data,
						success: function (response) {
							jQuery( "label[for='csv_file']" ).children( 'span' ).text( '' );
							if ( response.status == 'error') {
								jQuery( '.wqbo-csv-status' ).html( '<span class="error" >' + response.message + '</span>' );
							} else {
								if (response.errors_data) {
									html  = '<div class="show-errors" id="show-errors" style="display:none"><ul class="file_errors">';
									jQuery.each(
										JSON.parse( response.errors_data ),
										function (ind,item) {
											console.log( item )
											html += '<li>' + item + '</li>';
										}
									)
									html += '</ul><div class="close-button"><button type="button" name="close" class="close-popup" onclick="closePopup()"> Close </button></div></div>';
									jQuery( '.wqbo-csv-status' ).html( '<a href="javascript:void(0)" data-id="show-errors" onclick="showPopup(this)">View Errors</a>' );

									// console.log( html );
									jQuery( html ).insertAfter( '.wqbo-csv-status' );

								} else {
									jQuery( '.wqbo-csv-status' ).html( '<span class="success">' + response.message + '</span>' );
								}
								jQuery( '.wqbo-bucket' ).html( response.data );
								jQuery( "#wqbo-csv-order-form" ).trigger( "reset" );
							}
						},
						error: function (response) {
							console.log( 'error' );
						}

					}
				);
			}
		);

		jQuery( "#wqbo-order-form" ).submit(
			function (e) {
				e.preventDefault();

				if (jQuery( 'input[name=wqbo_product]' ).attr( 'data-product' ) != undefined && jQuery( 'input[name=wqbo_product]' ).attr( 'data-product' ) != '' && jQuery( 'input[name=wqbo_quantity]' ).val()) {
					addToBucket();
				}
			}
		);

		jQuery( '.ctrl_enter' ).keydown(
			function (e) {
				if ( e.ctrlKey && e.keyCode == 13 && jQuery( 'input[name=wqbo_product]' ).attr( 'data-product' ) != undefined && jQuery( 'input[name=wqbo_product]' ).attr( 'data-product' ) != '' && jQuery( 'input[name=wqbo_quantity]' ).val() ) {
					addToBucket();
				}
			}
		);
		jQuery( document ).on(
			'click',
			'.wqbo-remove',
			function () {
				var data = {
					'action': 'wqo_remove_product_from_bucket',
					'product': jQuery( this ).attr( 'data-id' ),
					'wqbo_codeid': jQuery( this ).attr( 'data-codeid' ),
					'block_settings': jQuery( 'input[name=block_settings]' ).val(),
					'_wpnonce' : jQuery( "input[name=_wpnonce]" ).val()
				};
				jQuery.post(
					ajax_object.ajax_url,
					data,
					function (response) {
						jQuery( '.wqbo-bucket' ).html( response );
					}
				);
			}
		);

		jQuery( 'input[name=wqbo_quantity]' ).click(
			function () {
				jQuery( this ).trigger( 'change' );
			}
		);

		jQuery( 'input[name=wqbo_quantity]' ).keyup(
			function (key) {
				if (key.which !== 13) {
					jQuery( this ).trigger( 'change' );
				}
			}
		);

		jQuery( 'input[name=wqbo_quantity]' ).change(
			function () {
				if (jQuery( 'input[name=wqbo_product]' ).attr( 'data-product' ) != undefined && jQuery( 'input[name=wqbo_product]' ).attr( 'data-product' ) != '') {
					var quantityChange;
					if (quantityChange) {
						quantityChange.abort();
					}
					var $this = jQuery( this );
					var data  = {
						'action': 'wqo_calculate_price',
						'product': jQuery( 'input[name=wqbo_product]' ).attr( 'data-product' ),
						'wqbo_codeid': jQuery( 'input[name=wqbo_product]' ).attr( 'data-codeid' ),
						'wqbo_url': jQuery( 'input[name=wqbo_product]' ).attr( 'data-url' ),
						'block_settings': jQuery( 'input[name=block_settings]' ).val(),
						'_wpnonce': jQuery( 'input[name=_wpnonce]' ).val(),
						// 'product_visibility' : jQuery( 'input[name=wqbo_product]' ).attr( 'data-vis' ),
						// 'role_discount' : jQuery( 'input[name=wqbo_product]' ).attr( 'data-discount' ),
						'quantity': jQuery( this ).val()
					};
					quantityChange = jQuery.post(
						ajax_object.ajax_url,
						data,
						function (response) {
							if (response) {
								jQuery( '.wqbo-price' ).html( response );
							}
						}
					);
				}
			}
		);

	}
);
