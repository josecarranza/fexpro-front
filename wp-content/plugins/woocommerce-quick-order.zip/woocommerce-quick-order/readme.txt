=== Quick Order for WooCommerce ===
Contributors: Codup.co
Tags: b2b, e-commerce, commerce,
Requires at least: 4.0
Tested up to: 5.5
Requires PHP: 5.6
WC requires at least: 2.5
WC tested up to: 4.3.3
Woo: 4891278:d87835e671dc48be084f55081f2904f3