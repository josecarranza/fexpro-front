<?php
/**
 * PLugin Setting file for creatin dynamic shortcodes.
 *
 * @package B2B_Quick_Order/templates
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

if ( ! class_exists( 'WQBO_Settings' ) ) {

	/**
	 * Dynamic shortcode settings.
	 */
	class WQBO_Settings {


		/**
		 * RFQ Variable.
		 *
		 * @var string $rfq rfq Variable.
		 */
		public $rfq;

		/**
		 * Category Variable.
		 *
		 * @var string $cat Category Variable.
		 */
		public $cat;

		/**
		 * CSV  Enable/Disable.
		 *
		 * @var bool $csv_check CSV  Enable/Disable.
		 */
		public $csv_check;

		/**
		 * CSV Title.
		 *
		 * @var string $csv_text CSV Title.
		 */
		public $csv_text;

		/**
		 * Thumbnail Title.
		 *
		 * @var string $thumbnail_title Thumbnail Title.
		 */
		public $thumbnail_title;

		/**
		 * Product Title.
		 *
		 * @var string $product_title Product Title.
		 */
		public $product_title;

		/**
		 * Quantity Title.
		 *
		 * @var string $quantity_title Quantity Title.
		 */
		public $quantity_title;

		/**
		 * Price Title.
		 *
		 * @var string $price_title Price Title.
		 */
		public $price_title;

		/**
		 * Action Title.
		 *
		 * @var string $actions_title Action Title.
		 */
		public $actions_title;

		/**
		 * Constructor.
		 *
		 * @param string $settings Settings.
		 */
		public function __construct( $settings = false ) {

			add_action( 'init', array( $this, 'wqbo_input_default_settings' ) );

			$this->default_settings();

			if ( $settings ) {
				$this->init_settings( $settings );
			}
			add_action( 'plugins_loaded', array( $this, 'hooks' ) );
			// $this->hooks();
		}

		/**
		 * Insert Default Settings.
		 */
		public function wqbo_input_default_settings() {

			if ( empty( get_option( 'wqbo_settings', false ) ) ) {

				$data = array(
					'csv_text'        => 'Upload your order',
					'thumbnail_title' => 'Thumbnail',
					'product_title'   => 'Products',
					'quantity_title'  => 'Quantity',
					'price_title'     => 'Price',
					'actions_title'   => 'Actions',
					'cat'             => 0,
					'csv_check'       => 0,
					'rfq'             => 0,
				);

				update_option( 'wqbo_settings', json_encode( $data ) );
			}

		}
		/**
		 * Default Settings.
		 */
		public function default_settings() {
			$this->rfq             = 0;
			$this->cat             = 0;
			$this->csv_check       = 0;
			$this->csv_text        = __( 'Upload your order', 'woocommerce-quick-order' );
			$this->thumbnail_title = __( 'Thumbnail', 'woocommerce-quick-order' );
			$this->product_title   = __( 'Products', 'woocommerce-quick-order' );
			$this->quantity_title  = __( 'Quantity', 'woocommerce-quick-order' );
			$this->price_title     = __( 'Price', 'woocommerce-quick-order' );
			$this->actions_title   = __( 'Actions', 'woocommerce-quick-order' );

		}

		/**
		 * Init Settings.
		 *
		 * @param string $settings Init Settings.
		 */
		public function init_settings( $settings ) {
			$this->rfq             = isset( $settings->rfq ) ? $settings->rfq : 0;
			$this->cat             = isset( $settings->cat ) ? $settings->cat : 0;
			$this->csv_check       = isset( $settings->csv_check ) ? $settings->csv_check : 0;
			$this->csv_text        = isset( $settings->csv_text ) ? $settings->csv_text : __( 'Upload your order', 'woocommerce-quick-order' );
			$this->thumbnail_title = $settings->thumbnail_title;
			$this->product_title   = $settings->product_title;
			$this->quantity_title  = $settings->quantity_title;
			$this->price_title     = $settings->price_title;
			$this->actions_title   = $settings->actions_title;
		}

		/**
		 * Provide hooks.
		 */
		public function hooks() {
			add_action( 'admin_menu', array( $this, 'add_settings_menu' ), 99 );
			add_action( 'admin_enqueue_scripts', array( $this, 'quick_order_admin_scripts' ) );
			add_filter( 'wp_dropdown_cats', array( $this, 'quick_order_multiselect_cats' ), 10, 2 );

		}

		/**
		 * Add Seetings Menu.
		 */
		public function add_settings_menu() {
			add_submenu_page( 'woocommerce', __( 'Woocommerce Quick Order Settings', 'woocommerce-quick-order' ), __( 'Quick Order', 'woocommerce-quick-order' ), 'edit_posts', 'wqbo-quick-order-settings', array( $this, 'quick_order_settings_page' ) );
		}

		/**
		 * Quick Order Settings Page.
		 */
		public function quick_order_settings_page() {
			if ( wp_verify_nonce( filter_input( INPUT_POST, '_wpnonce' ), 'wqbo-settings' ) && filter_input( INPUT_POST, 'wqbo_submit' ) ) {
				$settings = $this->process_form( $_POST );
			}

			if ( filter_input( INPUT_GET, 'action' ) == 'delete' && filter_input( INPUT_GET, 'shortcodeid' ) ) {
				$settings = get_option( 'wqbo_shortcode_ids', false );

				if ( $settings ) {
					$settings = json_decode( $settings, true );
					if ( false !== array_search( intval( filter_input( INPUT_GET, 'shortcodeid' ) ), $settings ) ) {
						$search_key = array_search( intval( filter_input( INPUT_GET, 'shortcodeid' ) ), $settings );
						unset( $settings[ $search_key ] );

						update_option( 'wqbo_shortcode_ids', json_encode( $settings ) );
						delete_option( 'wqbo_settings_' . filter_input( INPUT_GET, 'shortcodeid' ) );

						wp_redirect( admin_url( 'admin.php?page=wqbo-quick-order-settings' ) );
						exit();

					}
				}
			}
			if ( ! function_exists( 'wc_help_tip' ) ) {
				require_once '/includes/wc-core-functions.php';
			}

			wc_get_template(
				'/admin/settings.php',
				array(
					'cat'             => $this->cat,
					'csv_check'       => $this->csv_check,
					'csv_text'        => $this->csv_text,
					'thumbnail_title' => $this->thumbnail_title,
					'product_title'   => $this->product_title,
					'quantity_title'  => $this->quantity_title,
					'price_title'     => $this->price_title,
					'actions_title'   => $this->actions_title,
					'rfq'             => $this->rfq,
				),
				'woocommerce-quick-order',
				WQBO_TEMP_DIR
			);
		}

		/**
		 * Process Form.
		 *
		 * @param string $post_data Process form.
		 */
		public function process_form( $post_data ) {
			$post_shortcode_id = ! empty( $post_data['shortcodeid'] ) ? $post_data['shortcodeid'] : '';

			unset( $post_data['shortcodeid'] );
			unset( $post_data['wqbo_submit'] );
			unset( $post_data['_wpnonce'] );

			// categories.
			if ( isset( $post_data['cat'] ) ) {
				$post_data['cat'] = json_encode( $post_data['cat'] );
			} else {
				$post_data['cat'] = 0;
			}

			// csv import.
			if ( ! isset( $post_data['csv_check'] ) ) {
				$post_data['csv_check'] = 0;
			}
			if ( ! isset( $post_data['rfq'] ) ) {
				$post_data['rfq'] = 0;
			}

			if ( empty( $post_shortcode_id ) ) {
				update_option( 'wqbo_settings', json_encode( $post_data ) );
			} else {
				if ( 'new' == $post_shortcode_id ) {
					$id = $this->set_shortcode_ids( $post_data );
					wp_redirect( admin_url( 'admin.php?page=wqbo-quick-order-settings&shortcodeid=' . $id ) );
					exit();
				} else {
					$this->set_shortcode_ids( $post_data, $post_shortcode_id );
				}
			}

			$this->init_settings( (object) $post_data );
		}

		/**
		 * Set Short code ids.
		 *
		 * @param array $post_data set short code.
		 * @param int   $id set short code.
		 */
		public function set_shortcode_ids( $post_data, $id = false ) {
			$options = json_decode( get_option( 'wqbo_shortcode_ids', false ), true );

			if ( $options ) {
				if ( count( $options ) > 0 && ! $id ) {
					$id = intval( end( $options ) ) + 1;
				}
				if ( ! in_array( $id, $options ) ) {
					array_push( $options, $id );
				}
			} else {
				$id        = 1;
				$options[] = $id;
			}

			update_option( 'wqbo_shortcode_ids', json_encode( $options ) );
			update_option( 'wqbo_settings_' . $id, json_encode( $post_data ) );
			return $id;
		}

		/**
		 * Multi Select Categories.
		 *
		 * @param string $output Multi Select Categories.
		 * @param array  $r Multi Select Categories.
		 */
		public function quick_order_multiselect_cats( $output, $r ) {
			if ( ! empty( $r['multiple'] ) ) {
				$output = preg_replace( '/<select(.*?)>/i', '<select$1 multiple="multiple">', $output );
				$output = preg_replace( '/name=([\'"]{1})(.*?)\1/i', 'name=$2[]', $output );
			}
			return $output;
		}

		/**
		 * Quick Order Admin Scripts.
		 *
		 * @param string $page to current page.
		 */
		public function quick_order_admin_scripts( $page ) {

			if ( 'woocommerce_page_wqbo-quick-order-settings' == $page ) {
				wp_register_style( 'wqbo-settings-style', WQBO_PLUGIN_URL . 'public/admin/css/style.css', '', true );
				wp_register_style( 'wqbo-select-woo-css', WQBO_PLUGIN_URL . 'public/admin/css/select2.min.css', '', true );

				wp_register_script( 'wqbo-select-woo-js', WQBO_PLUGIN_URL . 'public/admin/js/select2.min.js', array( 'jquery' ), '1.12.4' );
				wp_register_script( 'wqbo-admin-script', WQBO_PLUGIN_URL . 'public/admin/js/admin-script.js', array( 'jquery', 'jquery-tiptip' ), '1.12.4' );

			}
		}
	}
}
