(function (blocks, element) {

	var el                    = wp.element.createElement,
			registerBlockType = wp.blocks.registerBlockType,
			ServerSideRender  = wp.components.ServerSideRender,
			ToggleControl     = wp.components.ToggleControl,
			TextControl       = wp.components.TextControl,
			SelectControl     = wp.components.SelectControl,
			CheckboxControl   = wp.components.CheckboxControl,
			InspectorControls = wp.editor.InspectorControls;
	var blockStyle            = {
		backgroundColor: '#900',
		color: '#fff',
		padding: '20px',
	};
	blocks.registerBlockType(
		'wqbo/quick-order',
		{
			title: 'Quick Order',
			icon: 'filter',
			category: 'widgets',
			edit: function (props) {
				return [

				el(
					ServerSideRender,
					{
						block: 'wqbo/quick-order',
						attributes: props.attributes,
					}
				),
				el(
					InspectorControls,
					{},
					el(
						TextControl,
						{
							label: settings.cat,
							value: props.attributes.cat,
							onChange: (value) => {
								props.setAttributes( {cat: value} );
							},
							help: 'Add comma separated category ids with "[]" (i.e [1,2]) to exclude products from search or CSV .'
						}
					),
					el(
						ToggleControl,
						{
							label: 'CSV Enable/Disable',
							checked: props.attributes.csv_check,
							onChange: function () {
								return props.setAttributes( {csv_check: ! props.attributes.csv_check} );
							},
							}
					),
					el(
						TextControl,
						{
							label: 'CSV Heading',
							value: props.attributes.csv_text,
							onChange: (value) => {
								props.setAttributes( {csv_text: value} );
							},
						}
					),
					el(
						TextControl,
						{
							label: settings.thumbnail_label + ' column label',
							value: props.attributes.thumbnail_label,
							onChange: (value) => {
								props.setAttributes( {thumbnail_label: value} );
							},
							help: ''
							}
					),
					el(
						TextControl,
						{
							label: settings.product_label + ' column label',
							value: props.attributes.product_label,
							onChange: (value) => {
								props.setAttributes( {product_label: value} );
							},
							help: ''
						}
					),
					el(
						TextControl,
						{
							label: settings.quantity_label + ' column label',
							value: props.attributes.quantity_label,
							onChange: (value) => {
								props.setAttributes( {quantity_label: value} );
							},
							help: ''
						}
					),
					el(
						TextControl,
						{
							label: settings.price_label + ' column label',
							value: props.attributes.price_label,
							onChange: (value) => {
								props.setAttributes( {price_label: value} );
							},
							help: ''
							}
					),
					el(
						TextControl,
						{
							label: settings.action_label + ' column label',
							value: props.attributes.action_label,
							onChange: (value) => {
								props.setAttributes( {action_label: value} );
							},
							help: ''
						}
					),
					el(
						ToggleControl,
						{
							help: "if B2B Ecommerce is activated",
							label: 'Request For Quote',
							checked: props.attributes.rfq,
							onChange: function () {
								return props.setAttributes( {rfq: ! props.attributes.rfq} );
							},
						}
					),
				),
				];
			},
			save: function () {
				return null;
			},
		}
	);
}(window.wp.blocks, window.wp.element, window.wp.components, window.wp.editor));
