<?php
/**
 * PLugin Guttenberg configuration file for set blocks
 *
 * @package B2B_Quick_Order/templates
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

if ( ! class_exists( 'WQBO_Guttenberg_Block' ) ) {

	/**
	 * Guttenberg Class.
	 */
	class WQBO_Guttenberg_Block {

		/**
		 * Construct.
		 */
		public function __construct() {
			// include_once 'gutenberg-helper-functions.php';.
			add_action( 'init', array( $this, 'register_block' ) );
		}

		/**
		 * BLock function.
		 */
		public function register_block() {
			if ( ! function_exists( 'register_block_type' ) ) {
				return;
			}

			$settings = $this->wqbo_default_settings();

			foreach ( $settings as $key => $value ) {
				$attributes[ $key ]['type'] = 'string';

				if ( 'csv_check' == $key || 'rfq' == $key ) {
					$attributes[ $key ]['type'] = 'boolean';
				}

				$attributes[ $key ]['default'] = $value;
			}

			wp_register_script(
				'wqbo-quick-order-block-script',
				WQBO_PLUGIN_URL . 'includes/gutenberg/quick-order/assets/quick-order-block-script.js',
				array( 'wp-blocks', 'wp-element', 'wp-components', 'wp-editor' ),
				1.0
			);
			wp_localize_script( 'wqbo-quick-order-block-script', 'settings', $settings );

			wp_register_style( 'wqbo-quick-order-block-style', WQBO_PLUGIN_URL . 'includes/gutenberg/quick-order/assets/quick-order-block-style.css', '', true );
			wp_enqueue_style( 'wqbo-quick-order-block-style' );

			register_block_type(
				'wqbo/quick-order',
				array(
					'attributes'      => $attributes,
					'editor_script'   => 'wqbo-quick-order-block-script',
					'editor_style'    => 'wqbo-quick-order-block-style',
					'render_callback' => array( $this, 'wqbo_quick_order_shortcode' ),
				)
			);
		}

		/**
		 * Block default setting.
		 */
		public function wqbo_default_settings() {
				return array(
					'rfq'             => 0,
					'rfq_enable'      => ( in_array( 'b2b-ecommerce-for-woocommerce/b2b-ecommerce-for-woocommerce.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) ) ? 1 : 0,
					'csv_check'       => 0,
					'csv_text'        => __( 'Upload your order', 'woocommerce-quick-order' ),
					'thumbnail_label' => __( 'Thumbnail', 'woocommerce-quick-order' ),
					'product_label'   => __( 'Product', 'woocommerce-quick-order' ),
					'quantity_label'  => __( 'Quantity', 'woocommerce-quick-order' ),
					'price_label'     => __( 'Price', 'woocommerce-quick-order' ),
					'action_label'    => __( 'Action', 'woocommerce-quick-order' ),
					'cat'             => '',
				);
		}

		/**
		 * Function hooked to add quick order short code
		 * to be placed anywhere on web site.
		 *
		 * @param array $block_settings all block setting stored in array.
		 *
		 * @return html $output
		 */
		public function wqbo_quick_order_shortcode( $block_settings ) {
			$codeid       = 'page_' . get_the_ID();
			WC()->session = new WC_Session_Handler();
			WC()->session->init();

			if ( wp_verify_nonce( filter_input( INPUT_POST, '_wpnonce' ), 'wqbo-quick-order' ) && filter_input( INPUT_POST, 'wqbo-quick-order-submit' ) && filter_input( INPUT_POST, 'wqbo_product' ) ) {

					$product_array             = explode( ' - ', filter_input( INPUT_POST, 'wqbo_product' ) );
					$data[ $product_array[0] ] = array(
						'product'  => $product_array[0],
						'quantity' => filter_input( INPUT_POST, 'wqbo_quantity' ),
					);
					if ( null == $_SESSION['wqbo_bucket'] ) {
							$_SESSION['wqbo_bucket'] = $data;
					} else {
							$bucket = $_SESSION['wqbo_bucket'];
						if ( isset( $bucket[ $product_array[0] ] ) ) {
								$bucket[ $product_array[0] ]['quantity'] = $bucket[ $product_array[0] ]['quantity'] + filter_input( INPUT_POST, 'wqbo_quantity' );
						} else {
								$bucket = $bucket + $data;
						}

						$_SESSION['wqbo_bucket'] = $bucket;
					}
					wc_add_notice( __( 'Product successfully added in bucket', 'woocommerce-quick-order' ), 'success' );
			}

			if ( ( null != $_SESSION['wqbo_bucket'] ) ) {
				$bucket_products = $_SESSION['wqbo_bucket'];
			} else {
				$bucket_products = array();
			}

			wc_get_template(
				'/frontend/quick-order.php',
				array(
					'bucket_products' => $bucket_products,
					'codeid'          => $codeid,
				),
				'woocommerce-quick-order',
				WQBO_TEMP_DIR
			);

		}


	}
	new WQBO_Guttenberg_Block();
}
