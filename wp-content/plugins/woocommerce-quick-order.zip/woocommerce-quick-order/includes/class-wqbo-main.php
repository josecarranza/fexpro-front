<?php
/**
 * Template for the tier entry. Based on the WooCommerce file class-wc-admin-settings.php.
 *
 * @package B2B_Quick_Order/templates
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

if ( ! class_exists( 'WQBO_Main' ) ) {

	/**
	 * Main Front-end class.
	 */
	class WQBO_Main {

		/**
		 * Constructor.
		 */
		public function __construct() {
			add_shortcode( 'wqbo_quick_order', array( $this, 'quick_order_form' ) );

			add_action( 'wp_enqueue_scripts', array( $this, 'quick_order_scripts' ) );

			add_action( 'wp_ajax_wqo_product_search', array( $this, 'wqo_product_search' ) );
			add_action( 'wp_ajax_nopriv_wqo_product_search', array( $this, 'wqo_product_search' ) );

			add_action( 'wp_ajax_wqo_calculate_price', array( $this, 'wqo_calculate_price' ) );
			add_action( 'wp_ajax_nopriv_wqo_calculate_price', array( $this, 'wqo_calculate_price' ) );

			add_action( 'wp_ajax_wqo_add_products_in_cart', array( $this, 'wqo_add_products_in_cart' ) );
			add_action( 'wp_ajax_nopriv_wqo_add_products_in_cart', array( $this, 'wqo_add_products_in_cart' ) );

			add_action( 'wp_ajax_wqo_add_products_in_rfq', array( $this, 'wqo_add_products_in_rfq' ) );
			add_action( 'wp_ajax_nopriv_wqo_add_products_in_rfq', array( $this, 'wqo_add_products_in_rfq' ) );

			add_action( 'wp_ajax_wqo_remove_product_from_bucket', array( $this, 'wqo_remove_product_from_bucket' ) );
			add_action( 'wp_ajax_nopriv_wqo_remove_product_from_bucket', array( $this, 'wqo_remove_product_from_bucket' ) );

			add_action( 'wp_ajax_wqo_add_csv_product_in_bucket', array( $this, 'wqo_add_csv_product_in_bucket' ) );
			add_action( 'wp_ajax_nopriv_wqo_add_csv_product_in_bucket', array( $this, 'wqo_add_csv_product_in_bucket' ) );

			add_action( 'wp_ajax_wqo_add_product_in_bucket', array( $this, 'wqo_add_product_in_bucket' ) );
			add_action( 'wp_ajax_nopriv_wqo_add_product_in_bucket', array( $this, 'wqo_add_product_in_bucket' ) );

			add_action( 'wp_ajax_wqo_fetch_product_image', array( $this, 'wqo_fetch_product_image' ) );
			add_action( 'wp_ajax_nopriv_wqo_fetch_product_image', array( $this, 'wqo_fetch_product_image' ) );

			add_filter( 'plugin_row_meta', array( $this, 'plugin_settings_link' ), 10, 2 );

			add_action( 'init', array( $this, 'init' ) );
		}

		/**
		 * Init Function.
		 */
		public function init() {

			if ( ! session_id() ) {
				session_start();
			}
			if ( empty( $_SESSION['wqbo_bucket'] ) ) {
				$_SESSION['wqbo_bucket'] = '';
			}

		}



		/**
		 * Ajax Response.
		 *
		 * @param array $array for json response.
		 */
		public function response( array $array ) {
			return wp_send_json( $array );
		}

		/**
		 * Quick Order Form.
		 *
		 * @param int $attr shortcode id.
		 */
		public function quick_order_form( $attr ) {
			if ( isset( $attr['code-id'] ) ) {
				if ( get_option( 'wqbo_settings_' . $attr['code-id'] ) ) {
					$codeid = $attr['code-id'];
				}
			} else {
				$codeid = 0;
			}

			if ( ! is_admin() && isset( $codeid ) ) {
				WC()->session = new WC_Session_Handler();
				WC()->session->init();

				$bucket_products = array();

				if ( ! empty( $_SESSION['wqbo_bucket'] ) ) {
					$bucket_products = $_SESSION['wqbo_bucket'];
				}

				ob_start();

				wc_get_template(
					'/frontend/quick-order.php',
					array(
						'attr'            => $attr,
						'bucket_products' => $bucket_products,
						'codeid'          => $codeid,
					),
					'woocommerce-quick-order',
					WQBO_TEMP_DIR
				);

				$output = ob_get_contents();
				ob_get_clean();
				return $output;

			}
		}

		/**
		 * Plugins Scripts.
		 */
		public function quick_order_scripts() {
			wp_enqueue_style( 'wqbo-style', WQBO_PLUGIN_URL . 'public/css/style.css', null, rand() );

			wp_register_script( 'wqbo-script', WQBO_PLUGIN_URL . 'public/js/script.js', array( 'jquery', 'jquery-ui-autocomplete' ), rand() );
			wp_localize_script(
				'wqbo-script',
				'ajax_object',
				array(
					'ajax_url' => admin_url( 'admin-ajax.php' ),
				)
			);
		}

		/**
		 * Get Parent Products.
		 */
		public function get_parent_products() {
			global $wpdb;
			$parent_array = array();
			$results      = $wpdb->get_results( "SELECT DISTINCT post_parent FROM {$wpdb->prefix}posts WHERE post_type = 'product_variation'" );
			if ( $results ) {
				foreach ( $results as $parent ) {
					array_push( $parent_array, $parent->post_parent );
				}
			}
			return $parent_array;
		}

		/**
		 * Get non RFQ products.
		 */
		public function get_non_rfq() {
			$array     = array();
			$the_query = new WP_Query(
				array(
					'posts_per_page' => -1,
					'post_type'      => array( 'product' ),
					'post_status'    => 'publish',
					'meta_query'     => array(
						array(
							'key'     => 'enable_rfq',
							'value'   => 'yes',
							'compare' => '!=',
						),
					),
				)
			);

			if ( $the_query->have_posts() ) {
				while ( $the_query->have_posts() ) {
					$the_query->the_post();
					array_push( $array, get_the_ID() );
				}
			}
			return $array;
		}

		/**
		 * Get post id from category id.
		 *
		 * @param array $category contain ids in array for getting products id.
		 */
		public function get_category_for_exclude( $category ) {
			$array     = array();
			$the_query = new WP_Query(
				array(
					'posts_per_page' => -1,
					'post_type'      => array( 'product' ),
					'post_status'    => 'publish',
					'tax_query'      => array(
						array(
							'taxonomy' => 'product_cat',
							'field'    => 'term_id',
							'terms'    => $category,
							'operator' => 'IN',
						),
					),
				)
			);

			if ( $the_query->have_posts() ) {
				while ( $the_query->have_posts() ) {
					$the_query->the_post();
					array_push( $array, get_the_ID() );
				}
			}
			return $array;
		}

		/**
		 * Search By Keyword.
		 *
		 * @param string $s search a product.
		 * @param array  $category contain ids in array for exluding.
		 * @param bool   $rfq Only RFQ products come if rfq exist.
		 */
		public function search_by_s( $s, $category, $rfq ) {
			$parent_array     = $this->get_parent_products();
			$category_exclude = array();
			$rfq_exclude      = array();
			// product variations exluded where category set to not__in.
			if ( $category ) {
					$category         = array_map( 'intval', json_decode( wp_unslash( $category ) ) );
					$category_exclude = $this->get_category_for_exclude( $category );
			}

			if ( 0 !== $rfq ) {
				$rfq_exclude = $this->get_non_rfq();

			}

			$post_parent_not_in = array_merge( $category_exclude, $rfq_exclude );
			$post_not_in        = array_merge( $parent_array, $post_parent_not_in );

			$the_query = new WP_Query(
				array(
					's'                   => $s,
					'posts_per_page'      => -1,
					'post_type'           => array( 'product', 'product_variation' ),
					'post_status'         => 'publish',
					'category__not_in'    => $category,
					'post__not_in'        => $post_not_in,
					'post_parent__not_in' => $post_parent_not_in,
					'tax_query'           => array(
						array(
							'taxonomy' => 'product_type',
							'field'    => 'slug',
							'terms'    => array( 'booking' ),
							'operator' => 'NOT IN',
						),
						array(
							'taxonomy' => 'product_cat',
							'field'    => 'term_id',
							'terms'    => $category,
							'operator' => 'NOT IN',
						),
					),
				)
			);

			if ( $the_query->have_posts() ) {
				while ( $the_query->have_posts() ) {
					$the_query->the_post();
					$id    = get_the_ID();
					$img   = get_product_image( $id );
					$sku   = get_product_sku( $id );
					$title = get_product_title( $id );

					if ( $sku ) {
						$sku = $sku . ' - ';
					} else {
						$sku = '';
					}

					$results[] = array(
						'value' => $id,
						'label' => $sku . $title,
						'icon'  => $img,
					);
				}

				/* Restore original Post Data */
				wp_reset_postdata();
				return $results;
			} else {
				return false;
			}
		}

		/**
		 * Search By SKU.
		 *
		 * @param string $sku product search from sku.
		 * @param array  $category contain ids in array for exluding.
		 * @param bool   $rfq Only RFQ products come if rfq exist.
		 */
		public function search_by_sku( $sku, $category, $rfq ) {
			$parent_array     = $this->get_parent_products();
			$category_exclude = array();
			$rfq_exclude      = array();

			// product variations exluded where category set to not__in.
			if ( $category ) {
				$category         = array_map( 'intval', json_decode( wp_unslash( $category ) ) );
				$category_exclude = $this->get_category_for_exclude( $category );
			}

			if ( 0 !== $rfq ) {
				$rfq_exclude = $this->get_non_rfq();

			}

			$post_parent_not_in = array_unique( array_merge( $category_exclude, $rfq_exclude ) );
			$post_not_in        = array_unique( array_merge( $parent_array, $post_parent_not_in ) );
			$the_query          = new WP_Query(
				array(
					'posts_per_page'      => -1,
					'post_type'           => array( 'product', 'product_variation' ),
					'post_status'         => 'publish',
					'category__not_in'    => $category,
					'post__not_in'        => $post_not_in,
					'post_parent__not_in' => $post_parent_not_in,
					'meta_query'          => array(
						array(
							'key'     => '_sku',
							'value'   => $sku,
							'compare' => 'LIKE',
						),
					),
					'tax_query'           => array(
						array(
							'taxonomy' => 'product_type',
							'field'    => 'slug',
							'terms'    => array( 'booking' ),
							'operator' => 'NOT IN',
						),
						array(
							'taxonomy' => 'product_cat',
							'field'    => 'term_id',
							'terms'    => $category,
							'operator' => 'NOT IN',
						),
					),
				)
			);

			if ( $the_query->have_posts() ) {
				while ( $the_query->have_posts() ) {
					$the_query->the_post();
					$id    = get_the_ID();
					$img   = get_product_image( $id );
					$sku   = get_product_sku( $id );
					$title = get_product_title( $id );

					if ( $sku ) {
						$sku = $sku . ' - ';
					} else {
						$sku = '';
					}

					$results[] = array(
						'value' => $id,
						'label' => $sku . $title,
						'icon'  => $img,
					);
				}
				// Restore original Post Data .
				wp_reset_postdata();
				return $results;
			} else {
				return false;
			}
		}

		/**
		 * Role Base Discount.
		 *
		 * @param int   $id for find a product.
		 * @param array $category contain ids in array for exluding.
		 * @param bool  $rfq Only RFQ products come if rfq exist.
		 */
		public function product_by_id( $id, $category, $rfq ) {
			$results          = array();
			$category_exclude = array();
			$rfq_exclude      = array();
			$rfq_enable       = array();

			// product variations exluded where category set to not__in.
			if ( $category ) {
				$category = array_map( 'intval', json_decode( wp_unslash( $category ) ) );
			} else {
				$category = 0;
			}

			if ( 0 !== $rfq ) {
				$rfq_exclude = $this->get_non_rfq();
			}

			if ( in_array( $id, $rfq_exclude ) ) {
				return $results;
			}

			$product = wc_get_product( $id );

			if ( $product ) {
					$img   = get_product_image( $id );
					$sku   = get_product_sku( $id );
					$title = get_product_title( $id );

				if ( $sku ) {
					$sku = $sku . ' - ';
				} else {
					$sku = '';
				}

					$results[] = array(
						'value' => $id,
						'label' => $sku . $title,
						'icon'  => $img,
					);

					return $results;
			} else {
				return false;
			}
		}

		/**
		 * Product Search.
		 */
		public function wqo_product_search() {
			if ( isset( $_POST['_wpnonce'] ) && wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['_wpnonce'] ) ), 'wqbo-quick-order' ) ) {
				$s              = isset( $_POST['search']['term'] ) ? sanitize_text_field( wp_unslash( $_POST['search']['term'] ) ) : '';
				$s              = trim( $s );
				$shortcode      = isset( $_POST['wqbo_codeid'] ) ? get_shortcode_data( intval( $_POST['wqbo_codeid'] ) ) : '';
				$block_settings = ( isset( $_POST['block_settings'] ) && ! empty( $_POST['block_settings'] ) ) ? json_decode( sanitize_text_field( wp_unslash( $_POST['block_settings'] ) ), true ) : '';

				if ( $block_settings ) {
					$shortcode = $block_settings;
				}

				if ( $shortcode ) {
					$results = $this->search_by_s( $s, $shortcode['cat'], (int) $shortcode['rfq'] );

					if ( ! $results ) {
							$results = $this->search_by_sku( $s, $shortcode['cat'], (int) $shortcode['rfq'] );
						if ( ! $results ) {
							$results[] = array(
								'label' => 'No Results Found',
								'icon'  => WQBO_PLUGIN_URL . 'public/img/no-image.png',
							);
						}
					}
					wp_send_json_success( $results );
					wp_die();
				} else {
					echo esc_attr__( 'Verification Failed', 'woocommerce-quick-order' );
					die();
				}
			} else {
				echo 'Nonce Failed';
				die();
			}
		}

		/**
		 * Get Available Attributes.
		 *
		 * @param string $variations Product Variations.
		 */
		public function get_available_attributes( $variations ) {
			$available_attributes = array();
			foreach ( $variations as $index => $variation ) {
				foreach ( $variation['attributes'] as $key => $attribute ) {
					$attribute_name = preg_replace( '/attribute_pa_/', '', $key );
					if ( ! in_array( $attribute, $available_attributes[ $attribute_name ] ) ) {
						$available_attributes[ $attribute_name ][] = $attribute;
					}
				}
			}
			return $available_attributes;
		}

		/**
		 * Calculate Price.
		 */
		public function wqo_calculate_price() {
			global $wpdb;
			$userID = get_current_user_id();			
			$user_meta=get_userdata($userID);
			if ( wp_verify_nonce( filter_input( INPUT_POST, '_wpnonce' ), 'wqbo-quick-order' ) ) {
				$product        = filter_input( INPUT_POST, 'product' );
				$product_array  = explode( ' - ', $product );
				$product        = wc_get_product( $product_array[0] );
				//print_r($product);
				/* $product        = filter_input( INPUT_POST, 'product' );
				$product_array  = explode( ' - ', $product );
				$product        = wc_get_product( $product_array[0] );
				$price          = $product->get_price();
				$price          = ( $price ) * ( filter_input( INPUT_POST, 'quantity' ) );
				$codeid         = isset( $_POST['wqbo_codeid'] ) ? sanitize_text_field( wp_unslash( $_POST['wqbo_codeid'] ) ) : 0;
				$shortcode      = get_shortcode_data( $codeid );
				$url            = isset( $_POST['wqbo_url'] ) ? esc_url_raw( sanitize_text_field( wp_unslash( $_POST['wqbo_url'] ) ) ) : '';
				$block_settings = ( isset( $_POST['block_settings'] ) && ! empty( $_POST['block_settings'] ) ) ? json_decode( sanitize_text_field( wp_unslash( $_POST['block_settings'] ) ), true ) : '';

				if ( $block_settings ) {
					$shortcode = $block_settings;
				}

				if ( in_array( 'b2b-ecommerce-for-woocommerce/b2b-ecommerce-for-woocommerce.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) && $shortcode ) {

					if ( ! is_user_logged_in() && 'yes' == get_option( 'codup_enable_hide_catalogue' ) ) {

						if ( function_exists( 'is_required_login' ) ) {
							$enabled = is_required_login( $product );
						}

						if ( $enabled ) {
							echo '<style>button.single_add_to_cart_button{ display: none;}</style><a href="' . wp_kses_post( site_url() . '/my-account?returnPage=' . base64_encode( $url ) ) . '" name="required_login" value="' . esc_attr( $product->get_id() ) . '" class="single_required_login_button button alt">' . esc_attr__( 'SignIn To View', 'woocommerce-quick-order' ) . '</a>';
							wp_die();
						}
					}

					// role base discount.
					if ( is_user_logged_in() ) {
						$updated_price = role_base_discount( $product, filter_input( INPUT_POST, 'quantity' ) );
						if ( $updated_price ) {
							$price = ( ! empty( $product->get_regular_price() ) ) ? $product->get_regular_price() : $product->get_price();
							echo wp_kses_post( '<del>' . wc_price( $price ) . '</del> $ ' . number_format( $updated_price, 2 ) . $product->get_price_suffix() );
							wp_die();
						}
					}
				} */
				$product_id = $product->get_id();
				$abc = 0;
				for($i = 1; $i<=10; $i++)
				{
					if(get_post_meta( $product_id, 'size_box_qty'. $i, true ))
					{
						$abc += get_post_meta( $product_id, 'size_box_qty'. $i, true );
					}
				}
				if(get_user_meta( $userID, 'customer_margin', true))
				{
					
					$getMargin = get_user_meta( $userID, 'customer_margin', true);
					//echo $getMargin;
					$discountRule = (100 - $getMargin) / 100;
					//echo $discountRule;
					$user_group_table = _groups_get_tablename( 'user_group' );
					$getGroup = $wpdb->get_row("SELECT `group_id` FROM $user_group_table WHERE `user_id` = '$userID'");
					$getGroupID =  $getGroup->group_id;
					//echo $getGroupID;
					
					//echo $product_id;
					//$getChildren = $product->get_children();
					//print_r($getChildren);
					
					$getGroupPrice = $wpdb->get_row("SELECT `price` from {$wpdb->prefix}wusp_group_product_price_mapping WHERE `group_id` = '$getGroupID' AND `product_id` = $product_id");
					
					$price = $getGroupPrice->price * $discountRule * ( filter_input( INPUT_POST, 'quantity' ) ) * $abc;
				}
				else if($user_meta->roles[0] == 'custom_role_puerto_rico')
				{
					$prices  = get_post_meta($product_id, '_regular_price',  true);
					
					$price = $max * 1.25 * ( filter_input( INPUT_POST, 'quantity' ) ) * $abc;					
				}
				else
				{
					$user_group_table = _groups_get_tablename( 'user_group' );
					$getGroup = $wpdb->get_row("SELECT `group_id` FROM $user_group_table WHERE `user_id` = '$userID'");
					$getGroupID =  $getGroup->group_id;
					//echo $getGroupID;
					if($getGroupID == 2)
					{
						//print_r($getChildren);
						$getGroupPrice = $wpdb->get_row("SELECT `price` from {$wpdb->prefix}wusp_group_product_price_mapping WHERE `group_id` = '$getGroupID' AND `product_id` = $product_id");
						
						$price = $getGroupPrice->price * ( filter_input( INPUT_POST, 'quantity' ) ) * $abc;
					}
					else
					{
						$price = $product->get_regular_price() * ( filter_input( INPUT_POST, 'quantity' ) ) * $abc;
					}
				}
				//echo wp_kses_post( wc_price( $price ) . $product->get_price_suffix() );
				echo wc_price( $price );
				wp_die();
			}
		}

		/**
		 * Add Product In Cart.
		 */
		public function wqo_add_products_in_cart() {
			$bucket_products = $_SESSION['wqbo_bucket'];
			$args            = array(
				'posts_per_page' => -1,
				'post_type'      => array( 'product', 'product_variation' ),
				'post_status'    => 'publish',
				'post__in'       => array_keys( $bucket_products[ filter_input( INPUT_POST, 'wqbo_codeid' ) ] ),
			);
			$posts           = get_posts( $args );
			if ( $posts ) {
				foreach ( $posts as $key => $value ) {
					$product      = wc_get_product( $value );
					$product_data = $product->get_data();
					$quantity     = $bucket_products[ filter_input( INPUT_POST, 'wqbo_codeid' ) ][ $product_data['id'] ]['quantity'];
					if ( 'product' == $product->post_type ) {
						WC()->cart->add_to_cart( $product_data['id'], $quantity );
					} elseif ( 'product_variation' == $product->post_type ) {
						WC()->cart->add_to_cart( $product_data['parent_id'], $quantity, $product_data['id'] );
					}
				}
			}
			wc_add_notice( esc_attr__( 'Product(s) successfully added in cart', 'woocommerce-quick-order' ), 'success' );
			unset( $bucket_products[ filter_input( INPUT_POST, 'wqbo_codeid' ) ] );

			if ( count( $bucket_products ) > 0 ) {
				$_SESSION['wqbo_bucket'] = $bucket_products;
			} else {
				$_SESSION['wqbo_bucket'] = null;
			}
			echo 'success';
			wp_die();
		}

		/**
		 * Add Product In RFQ.
		 */
		public function wqo_add_products_in_rfq() {
			$bucket_products = $_SESSION['wqbo_bucket'];
			$args            = array(
				'posts_per_page' => -1,
				'post_type'      => array( 'product', 'product_variation' ),
				'post_status'    => 'publish',
				'post__in'       => array_keys( $bucket_products[ filter_input( INPUT_POST, 'wqbo_codeid' ) ] ),
			);
			$posts           = get_posts( $args );
			if ( $posts ) {
				foreach ( $posts as $key => $value ) {
					$product      = wc_get_product( $value );
					$product_data = $product->get_data();
					$variations   = array();
					$quantity     = $bucket_products[ filter_input( INPUT_POST, 'wqbo_codeid' ) ][ $product_data['id'] ]['quantity'];
					if ( 'product' == $product->post_type ) {
						WC()->rfq->add_to_cart( $product_data['id'], $quantity );
					} elseif ( 'product_variation' == $product->post_type ) {

						foreach ( $product->get_attributes() as $key => $attribute ) {
							if ( ! $product->is_type( 'variation' ) ) {
								continue;
							}

							// Get valid value from variation data.
							$attribute_key                = 'attribute_' . sanitize_title( $key );
							$variations[ $attribute_key ] = $attribute;
						}
						WC()->rfq->add_to_cart( $product_data['parent_id'], $quantity, $product_data['id'], $variations );
					}
				}
			}
			$url = '<a href="' . esc_url( site_url() . '/rfq' ) . '" tabindex="1" class="button wc-forward"> View RFQ </a>';
			/* translators: 1: view rfq*/
			wc_add_notice( sprintf( esc_attr__( 'Product(s) successfully added in RFQ %s', 'woocommerce-quick-order' ), wp_kses_post( $url ) ), 'success' );
			$_SESSION['wqbo_bucket'] = null;
			echo 'success';
			wp_die();
		}

		/**
		 * Update Basket Session.
		 *
		 * @param array $post_data for saving data in bucket session.
		 *
		 * @return array will return.
		 */
		public function update_bucket_session( $post_data ) {
			$_SESSION['wqbo_bucket'];
			$product = $post_data['wqbo_product'];

			$data[ $post_data['wqbo_codeid'] ][ $product ] = array(
				'product'  => $product,
				'quantity' => $post_data['wqbo_quantity'],
			);

			if ( null == $_SESSION['wqbo_bucket'] ) {
				return $data;
			} else {
				$bucket = $_SESSION['wqbo_bucket'];
				if ( isset( $bucket[ $post_data['wqbo_codeid'] ][ $product ] ) ) {
					$bucket[ $post_data['wqbo_codeid'] ][ $product ]['quantity'] = $bucket[ $post_data['wqbo_codeid'] ][ $product ]['quantity'] + $post_data['wqbo_quantity'];
				} elseif ( isset( $bucket[ $post_data['wqbo_codeid'] ] ) ) {
					$bucket[ $post_data['wqbo_codeid'] ] = $bucket[ $post_data['wqbo_codeid'] ] + $data[ $post_data['wqbo_codeid'] ];
				} else {

					$bucket = $bucket + $data;
				}
				return $bucket;
			}
		}

		/**
		 * Set OR Get session data.
		 *
		 * @param array $bucket_products for new entry .
		 * @param array $codeid for save data in existing shortcode .
		 * @param array $url for redirect back .
		 * @param array $block_settings if create from guttenberg .
		 */
		public function get_bucket_data( $bucket_products, $codeid ) {

			ob_start();

			wc_get_template(
				'/frontend/quick-order-bucket.php',
				array(
					'bucket_products' => $bucket_products,
					'codeid'          => $codeid,
				),
				'woocommerce-quick-order',
				WQBO_TEMP_DIR
			);

			$output = ob_get_contents();
			ob_get_clean();
			return wp_kses_post( $output );

		}

		/**
		 * Add Product In Basket With Import CSV.
		 */
		public function wqo_add_csv_product_in_bucket() {
			apply_filters( 'wc_customer_order_export_csv_enable_bom', false, $this );
			$status = array();
			if ( wp_verify_nonce( filter_input( INPUT_POST, '_wpnonce' ), 'wqbo-quick-order' ) ) {

				$filename = ( isset( $_FILES['csv_file']['name'] ) && ! empty( $_FILES['csv_file']['name'] ) ) ? sanitize_file_name( wp_unslash( $_FILES['csv_file']['name'] ) ) : '';

				$codeid = isset( $_POST['wqbo_codeid'] ) ? sanitize_text_field( wp_unslash( $_POST['wqbo_codeid'] ) ) : 0;

				$block_settings = ( isset( $_POST['block_settings'] ) && ! empty( $_POST['block_settings'] ) ) ? json_decode( sanitize_text_field( wp_unslash( $_POST['block_settings'] ) ), true ) : '';

				if ( $block_settings ) {
					$shortcode = $block_settings;
				} else {
					$codeid    = intval( $codeid );
					$shortcode = get_shortcode_data( $codeid );
				}

				if ( pathinfo( $filename, PATHINFO_EXTENSION ) == 'csv' ) {
					if ( ! empty( $shortcode ) ) {

						$file_id   = media_handle_upload( 'csv_file', 0 );
						$file_path = get_attached_file( $file_id );
						//$file_path = $_SERVER['DOCUMENT_ROOT'] . '/wp-content/uploa/csv_file.csv';
						if ( isset( $_FILES['csv_file']['size'] ) && $_FILES['csv_file']['size'] > 0 ) {
							$output = '';
							if ( fopen( $file_path, 'r' ) ) {
								$handle = fopen( $file_path, 'r' );
							} else {								//$this->response( $file_path );
								die( $file_path );
							}
							$i        = 0;
							$all_rows = array();
							$errors   = array();

							$csv_separator = ',';

							/*
							 @name: wqbo_separator_for_csv
							 @desc: Change separator if neeeded.
							 @param: (string) $csv_separator csv separator.
							 @package: B2B_Quick_Order
							 @module: backend
							 @type: filter
							*/
							$csv_separator = apply_filters( 'wqbo_separator_for_csv', $csv_separator );

							while ( $row = fgetcsv( $handle, 0, $csv_separator ) ) {
								$post_data = array();
								$pro       = $row[0];
								$quan      = intval( $row[1] );

								// first will be heading.
								if ( 0 == $i ) {
									$i++;
									continue;
								}

								// check quantity is int.
								if ( 0 == $quan ) {
									$errors[] = "<b> {$pro} </b> - " . ' Quantity must be an integer';
									continue;
								}

								$results = $this->search_by_sku( $pro, $shortcode['cat'], (int) $shortcode['rfq'] );

								if ( $results ) {
									$stock_quan   = intval( get_post_meta( $results[0]['value'], '_stock', true ) );
									$stock_status = get_post_meta( $results[0]['value'], '_stock_status', true );

									// check out of stock.

									if ( 'outofstock' == $stock_status ) {
										$errors[] = "<b> {$pro} </b> -  quantity out of stock ";
									} elseif ( ! empty( $stock_quan ) && $quan > $stock_quan ) {

										$post_data['wqbo_product']  = $results[0]['value'];
										$post_data['wqbo_quantity'] = $stock_quan;
										$errors[]                   = "<b> {$pro} </b> - " . ( $quan - $stock_quan ) . ' quantity out of stock';

									} else {
										$post_data['wqbo_product']  = $results[0]['value'];
										$post_data['wqbo_quantity'] = $quan;
									}
								} else {
									$results = $this->product_by_id( $pro, $shortcode['cat'], (int) $shortcode['rfq'] );

									if ( $results ) {
										$stock_quan   = intval( get_post_meta( $results[0]['value'], '_stock', true ) );
										$stock_status = get_post_meta( $results[0]['value'], '_stock_status', true );

										if ( 'outofstock' == $stock_status ) {
											$errors[] = "<b> {$pro} </b> -  quantity out of stock ";
										} elseif ( ! empty( $stock_quan ) && $quan > $stock_quan ) {
											$post_data['wqbo_product']  = $pro;
											$post_data['wqbo_quantity'] = $stock_quan;
											$errors[]                   = "<b> {$pro} </b> - " . ( $quan - $stock_quan ) . ' quantity out of stock ';
										} else {
											$post_data['wqbo_product']  = $pro;
											$post_data['wqbo_quantity'] = $quan;
										}
									} else {
										$errors[] = "<b> {$pro} </b> - " . ' not found';
									}
								}

								if ( count( $post_data ) > 0 ) {
									$post_data['wqbo_codeid'] = $codeid;
									$bucket_products          = $this->update_bucket_session( $post_data );
									$_SESSION['wqbo_bucket']  = $bucket_products;
								} else {
									if ( null != $_SESSION['wqbo_bucket'] ) {
										$bucket_products = $_SESSION['wqbo_bucket'];
									}
								}

								$i++;
							}
						}

						fclose( $handle );
						wp_delete_attachment( $file_id );
						if ( null != $_SESSION['wqbo_bucket'] && count( $bucket_products ) < 1 ) {
							$bucket_products = $_SESSION['wqbo_bucket'];
						}

						$data = $this->get_bucket_data( $bucket_products, $codeid, $url, $block_settings );

						if ( count( $errors ) > 0 ) {
							$status = array(
								'status'      => 'success',
								'message'     => esc_attr__( 'File import Successfully', 'woocommerce-quick-order' ),
								'errors_data' => json_encode( $errors ),
								'data'        => $data,
							);
						} else {
							$status = array(
								'status'  => 'success',
								'message' => esc_attr__( 'File import Successfully', 'woocommerce-quick-order' ),
								'data'    => $data,
							);
						}
					} else {
						$status = array(
							'status'  => 'error',
							'message' => esc_attr__( 'Something went wrong...', 'woocommerce-quick-order' ),
						);
					}
				} else {
					$status = array(
						'status'  => 'error',
						'message' => esc_attr__( 'File must be a csv', 'woocommerce-quick-order' ),
					);
				}
			} else {
				$status = array(
					'status'  => 'error',
					'message' => esc_attr__( 'verification Failed, please reload the page', 'woocommerce-quick-order' ),
				);
			}

			$this->response( $status );
			wp_die();
		}

		/**
		 * Add Product In Basket.
		 */
		public function wqo_add_product_in_bucket() {

			if ( wp_verify_nonce( filter_input( INPUT_POST, '_wpnonce' ), 'wqbo-quick-order' ) && filter_input( INPUT_POST, 'wqbo_product' ) ) {
				$bucket_products         = $this->update_bucket_session( $_POST );
				$_SESSION['wqbo_bucket'] = $bucket_products;
				$codeid                  = ( isset( $_POST['wqbo_codeid'] ) && ! empty( $_POST['wqbo_codeid'] ) ) ? sanitize_text_field( wp_unslash( $_POST['wqbo_codeid'] ) ) : 0;
				$url                     = isset( $_POST['wqbo_url'] ) ? esc_url_raw( wp_unslash( $_POST['wqbo_url'] ) ) : '';
				$block_settings          = ( isset( $_POST['block_settings'] ) && ! empty( $_POST['block_settings'] ) ) ? json_decode( sanitize_text_field( wp_unslash( $_POST['block_settings'] ) ), true ) : '';

				$data = $this->get_bucket_data( $bucket_products, $codeid, $url, $block_settings );
				$this->response(
					array(
						'status' => esc_attr__( 'success', 'woocommerce-quick-order' ),
						'data'   => $data,
					)
				);

			}
			wp_die();
		}

		/**
		 * Remove Product From Basket.
		 */
		public function wqo_remove_product_from_bucket() {
			if ( isset( $_POST['_wpnonce'] ) && wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['_wpnonce'] ) ), 'wqbo-quick-order' ) ) {
				if ( isset( $_POST['product'] ) && isset( $_POST['wqbo_codeid'] ) ) {
					$codeid         = ( isset( $_POST['wqbo_codeid'] ) && ! empty( $_POST['wqbo_codeid'] ) ) ? sanitize_text_field( wp_unslash( $_POST['wqbo_codeid'] ) ) : 0;
					$block_settings = ( isset( $_POST['block_settings'] ) && ! empty( $_POST['block_settings'] ) ) ? json_decode( sanitize_text_field( wp_unslash( $_POST['block_settings'] ) ), true ) : '';

					$bucket_products = $_SESSION['wqbo_bucket'];
					unset( $bucket_products[ $codeid ][ $_POST['product'] ] );

					if ( count( $bucket_products[ $codeid ] ) < 1 ) {
						unset( $bucket_products[ $codeid ] );
					}

					$_SESSION['wqbo_bucket'] = $bucket_products;

					ob_start();

					wc_get_template(
						'/frontend/quick-order-bucket.php',
						array(
							'bucket_products' => $bucket_products,
							'codeid'          => $codeid,
						),
						'woocommerce-quick-order',
						WQBO_TEMP_DIR
					);

					$output = ob_get_contents();
					ob_end_clean();
					echo wp_kses_post( $output );
				}
			}
			wp_die();
		}

		/**
		 * Fetch Product.
		 */
		public function wqo_fetch_product_image() {
			if ( filter_input( INPUT_POST, 'product' ) ) {
				$product = filter_input( INPUT_POST, 'product' );
				$image   = get_the_post_thumbnail_url( $product );
				if ( absint( $product ) && ! $image ) {
					$image = WQBO_PLUGIN_URL . '/public/img/no-image.png';
				}
				echo wp_kses_post( $image );
			}
			wp_die();
		}

		/**
		 * Add a custom link on plugin section
		 *
		 * @param string $links used for plugin setting redirection.
		 * @param string $file used to check file.
		 */
		public function plugin_settings_link( $links, $file ) {
			if ( 'codup-woocommerce-quick-order/codup-woocommerce-quick-order.php' == $file ) {
				$links[] = '<a href=" ' . esc_url( admin_url( 'admin.php?page=wqbo-quick-order-settings' ) ) . '" target="_blank">' . esc_attr__( 'Settings' ) . '</a>';
			}
			return $links;
		}

	}

}
$wqbo_main = new WQBO_Main();
