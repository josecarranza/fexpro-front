<?php
/**
 * All other classes fil load with class-wqbo-loader.php.
 *
 * @package B2B_Quick_Order/templates
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

if ( ! class_exists( 'WQBO_Loader' ) ) {
	/**
	 * Main Loader class to contain all plugin files.
	 */
	class WQBO_Loader {
		/**
		 * Construct.
		 */
		public function __construct() {
			add_action( 'plugins_loaded', array( $this, 'wqbo_load_plugin_textdomain' ) );
			$this->includes();
		}

		/**
		 * Includes.
		 */
		public function includes() {
			// inluding all classes here.
			include_once WQBO_ABSPATH . '/includes/class-wqbo-main.php';
			include_once WQBO_ABSPATH . '/includes/class-wqbo-settings.php';
			include_once WQBO_ABSPATH . '/includes/gutenberg/quick-order/class-wqbo-guttenberg-block.php';

			$settings = get_option( 'wqbo_settings', false );
			if ( filter_input( INPUT_GET, 'shortcodeid' ) ) {
				$get_option = get_option( 'wqbo_settings_' . filter_input( INPUT_GET, 'shortcodeid' ), false );
				$settings   = json_decode( $get_option );
			} elseif ( $settings ) {
				$settings = json_decode( $settings );
			}

			$wqbo_settings = new WQBO_Settings( $settings );
		}

		/**
		 * Languages loaded.
		 */
		public function wqbo_load_plugin_textdomain() {
			load_plugin_textdomain( 'woocommerce-quick-order', false, basename( WQBO_ABSPATH ) . '/languages/' );
		}

	}
}
$wqbo_loader = new WQBO_Loader();
