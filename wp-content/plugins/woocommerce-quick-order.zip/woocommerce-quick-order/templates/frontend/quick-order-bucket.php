<?php

$posts_result = array();

if ( ! empty( $bucket_products ) && isset( $bucket_products[ $codeid ] ) ) {
	$args         = array(
		'posts_per_page' => -1,
		'post_status'    => 'publish',
		'post_type'      => array( 'product', 'product_variation' ),
		'post__in'       => array_keys( $bucket_products[ $codeid ] ),
	);
	$posts_result = get_posts( $args );
}

/**
 * Quick order bucket file creating for showing bucket data.
 *
 * @package B2B_Quick_Order/templates
 */

global $wp;
wp_enqueue_style( 'wqbo-auto-complete', WQBO_PLUGIN_URL . 'public/css/auto-complete.css', null, '1.0' );

// if Guttunberg setting worked else default will be working.
if ( isset( $block_settings ) && ! empty( $block_settings ) ) {

	$options = array(
		'rfq'             => esc_html( $block_settings['rfq'], 'woocommerce-quick-order' ),
		'cat'             => esc_html( $block_settings['cat'], 'woocommerce-quick-order' ),
		'csv_check'       => esc_html( $block_settings['csv_check'], 'woocommerce-quick-order' ),
		'csv_text'        => esc_html( $block_settings['csv_check'], 'woocommerce-quick-order' ),
		'thumbnail_title' => esc_html( $block_settings['thumbnail_label'], 'woocommerce-quick-order' ),
		'product_title'   => esc_html( $block_settings['product_label'], 'woocommerce-quick-order' ),
		'quantity_title'  => esc_html( $block_settings['quantity_label'], 'woocommerce-quick-order' ),
		'price_title'     => esc_html( $block_settings['price_label'], 'woocommerce-quick-order' ),
		'actions_title'   => esc_html( $block_settings['action_label'], 'woocommerce-quick-order' ),
	);
} else {
	$options = array(
		'rfq'             => 0,
		'cat'             => 0,
		'csv_check'       => 0,
		'csv_text'        => __( 'Upload your order', 'woocommerce-quick-order' ),
		'thumbnail_title' => __( 'Thumbnail', 'woocommerce-quick-order' ),
		'product_title'   => __( 'Products', 'woocommerce-quick-order' ),
		'quantity_title'  => __( 'Quantity', 'woocommerce-quick-order' ),
		'price_title'     => __( 'Price', 'woocommerce-quick-order' ),
		'actions_title'   => __( 'Actions', 'woocommerce-quick-order' ),
	);
}

// if dynamically shortcode is working.
if ( 0 === $codeid && get_option( 'wqbo_settings' ) ) {
	$options = array_merge( $options, json_decode( get_option( 'wqbo_settings' ), true ) );
} elseif ( get_option( 'wqbo_settings_' . $codeid ) ) {
	$options = array_merge( $options, json_decode( get_option( 'wqbo_settings_' . $codeid ), true ) );
}
?>
<div class="wqbo-tbl-responsive">
	<table>
		<thead>
			<tr>
				<th><?php echo wp_kses_post( $options['thumbnail_title'] ); ?></td>
				<th><?php echo wp_kses_post( $options['product_title'] ); ?></th>
				<th><?php echo wp_kses_post( $options['quantity_title'] ); ?></th>
				<th><?php echo wp_kses_post( $options['price_title'] ); ?></th>
				<th><?php echo wp_kses_post( $options['actions_title'] ); ?></th>
			</tr>
		</thead>
		<?php
		$total = 0;
		
		if ( ! empty( $posts_result ) ) {
			global $wpdb;
			$userID = get_current_user_id();			
			$user_meta=get_userdata($userID);
			
			foreach ( $posts_result as $post_res ) {
				$product               = wc_get_product( $post_res );
				$product_data          = $product->get_data();
				$quantity              = $bucket_products[ $codeid ][ $product_data['id'] ]['quantity'];
								$image = get_the_post_thumbnail_url( $product->get_id() );
				if ( ! $image ) {
					$image = WQBO_PLUGIN_URL . 'public/img/no-image.png';
				}
				?>
				<tr>
					<td><img src="<?php echo wp_kses_post( $image ); ?>"/></td>
					<td><a href="<?php echo wp_kses_post( get_permalink( $product_data['id'] ) ); ?>" target="_blank"><?php echo wp_kses_post( get_product_title( $product_data['id'] ) ); ?></a><input type="hidden" name="product" value="<?php echo wp_kses_post( $product_data['id'] ); ?>" /></td>
					<td style="padding-left: 4%;"><?php echo wp_kses_post( $quantity ); ?></td>
					<td>
						<?php
						$price   = $product->get_price();
						$price   = ( $price ) * ( $quantity );
						$enabled = '';
						// product visibility && role base discount compatibility from b2b ecommerce.
						/* if ( in_array( 'b2b-ecommerce-for-woocommerce/b2b-ecommerce-for-woocommerce.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) ) {

							if ( ! is_user_logged_in() && 'yes' == get_option( 'codup_enable_hide_catalogue' ) ) {

								if ( function_exists( 'is_required_login' ) ) {
									$enabled = is_required_login( $product );
								}

								if ( $enabled ) {
									$url = ( isset( $url ) && ! empty( $url ) ) ? $url : home_url( $wp->request );
									?>
									<a href="<?php echo wp_kses_post( site_url() . '/my-account?returnPage=' . base64_encode( $url ) ); ?>" name="required_login" value="<?php echo esc_attr( $product->get_id() ); ?>" class="single_required_login_button button alt"><?php esc_attr_e( 'SignIn To View', 'woocommerce-quick-order' ); ?></a>
									<?php
								} else {
									$total += $price;
									echo wp_kses_post( wc_price( $price ) . $product->get_price_suffix() );
								}
							} else {
								// role base discount.
								if ( is_user_logged_in() ) {
									$updated_price = role_base_discount( $product, $quantity );
									if ( $updated_price ) {
										$total += $updated_price;
										$price  = ( ! empty( $product->get_regular_price() ) ) ? $product->get_regular_price() : $product->get_price();
										echo wp_kses_post( '<del>' . wc_price( $price ) . '</del> $ ' . number_format( $updated_price, 2 ) . $product->get_price_suffix() );

									} else {
										$total += $price;
										echo wp_kses_post( wc_price( $price ) . $product->get_price_suffix() );
									}
								} else {
									$total += $price;
									echo wp_kses_post( wc_price( $price ) . $product->get_price_suffix() );
								}
							}
						} else { */			
								$product_id = $product->get_id();
								$abc = 0;
								for($i = 1; $i<=10; $i++)
								{
									if(get_post_meta( $product_id, 'size_box_qty'. $i, true ))
									{
										$abc += get_post_meta( $product_id, 'size_box_qty'. $i, true );
									}
								}
								if(get_user_meta( $userID, 'customer_margin', true))
								{
									
									$getMargin = get_user_meta( $userID, 'customer_margin', true);
									//echo $getMargin;
									$discountRule = (100 - $getMargin) / 100;
									//echo $discountRule;
									$user_group_table = _groups_get_tablename( 'user_group' );
									$getGroup = $wpdb->get_row("SELECT `group_id` FROM $user_group_table WHERE `user_id` = '$userID'");
									$getGroupID =  $getGroup->group_id;
									//echo $getGroupID;
									
									//echo $product_id;
									//$getChildren = $product->get_children();
									//print_r($getChildren);
									
									$getGroupPrice = $wpdb->get_row("SELECT `price` from {$wpdb->prefix}wusp_group_product_price_mapping WHERE `group_id` = '$getGroupID' AND `product_id` = $product_id");
									
									$price = $getGroupPrice->price * $discountRule * $quantity * $abc;
								}
								else if($user_meta->roles[0] == 'custom_role_puerto_rico')
								{
									$prices  = get_post_meta($product_id, '_regular_price',  true);
									
									$price = $max * 1.25 * $quantity * $abc;					
								}
								else
								{
									$user_group_table = _groups_get_tablename( 'user_group' );
									$getGroup = $wpdb->get_row("SELECT `group_id` FROM $user_group_table WHERE `user_id` = '$userID'");
									$getGroupID =  $getGroup->group_id;
									//echo $getGroupID;
									if($getGroupID == 2)
									{
										//print_r($getChildren);
										$getGroupPrice = $wpdb->get_row("SELECT `price` from {$wpdb->prefix}wusp_group_product_price_mapping WHERE `group_id` = '$getGroupID' AND `product_id` = $product_id");
										
										$price = $getGroupPrice->price * $quantity * $abc;
									}
									else
									{
										$price = $product->get_regular_price() * $quantity * $abc;
									}
								}
								$total += $price;								
								echo wp_kses_post( wc_price( $price ) . $product->get_price_suffix() );
						/* } */
						?>
					</td>
					<td><a class="wqbo-remove wqbo-button" data-id="<?php echo wp_kses_post( $product_data['id'] ); ?>" data-codeid="<?php echo wp_kses_post( $codeid ); ?>"><?php esc_attr_e( 'Remove', 'woocommerce-quick-order' ); ?></a></td>
				</tr>
				<?php
			}
		} else {
			?>
			<tr>
				<td colspan="5"><?php esc_attr_e( 'No products in bucket', 'woocommerce-quick-order' ); ?></td>
			</tr>
			<?php
		}
		?>
		<tr class="wqbo-row-total">
			<td colspan="3"></td>
			<td class="font-bold font-md"><?php esc_attr_e( 'Total', 'woocommerce-quick-order' ); ?></td>
			<td class="font-bold font-md"><?php echo wp_kses_post( wc_price( $total ) ); ?></td>
		</tr>
		<tr>
			<td colspan="5">
				<br>
				<?php
				$disabled           = '';
				$button             = '';
				$add_to_rfq_btn_txt = get_option( 'codup-rfq_add_to_rfq_button_text' );
				if ( isset( $options['rfq'] ) && 1 == $options['rfq'] && in_array( 'b2b-ecommerce-for-woocommerce/b2b-ecommerce-for-woocommerce.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) ) {
					$button = $add_to_rfq_btn_txt ? $add_to_rfq_btn_txt : esc_attr__( 'Add to RFQ', 'woocommerce-quick-order' );
					if ( isset( $posts_result ) ) {
						$disabled = esc_attr__( 'wqbo_add_to_rfq', 'woocommerce-quick-order' );
					}
				} else {
					$button = esc_attr__( 'Add to cart', 'woocommerce-quick-order' );
					if ( isset( $posts_result ) ) {
						$disabled = ' wqbo_add_to_cart';
					}
				}
				?>
				<a class='button <?php echo empty( $enabled ) ? wp_kses_post( $disabled ) : 'disabled'; ?> wqbo-button' ><?php echo wp_kses_post( $button ); ?></a>
			</td>
		</tr>
	</table>
</div>
