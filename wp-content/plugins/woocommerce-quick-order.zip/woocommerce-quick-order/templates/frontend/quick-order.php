<?php
/**
 * Quick order file view shortcode functionality section.
 *
 * @package B2B_Quick_Order/templates
 */

global $wp;

add_thickbox();
wp_enqueue_script( 'wqbo-script' );
$wp_scripts_new = wp_scripts();
wp_enqueue_style( 'wqbo-admin-ui-css', 'https://ajax.googleapis.com/ajax/libs/jqueryui/' . $wp_scripts_new->registered['jquery-ui-core']->ver . '/themes/smoothness/jquery-ui.css', false, '1.0' );

$product_removed = WC()->session->get( 'wqbo_product_removed' ) != null ? WC()->session->get( 'wqbo_product_removed' ) : '';
if ( '' != $product_removed ) {
	wc_print_notice( $product_removed, 'success' );
	WC()->session->set( 'wqbo_product_removed', false );
}

// if Guttunberg setting worked else default will be working.
if ( isset( $block_settings ) ) {

	$options = array(
		'rfq'             => esc_html( $block_settings['rfq'], 'woocommerce-quick-order' ),
		'cat'             => esc_html( $block_settings['cat'], 'woocommerce-quick-order' ),
		'csv_check'       => esc_html( $block_settings['csv_check'], 'woocommerce-quick-order' ),
		'csv_text'        => esc_html( $block_settings['csv_text'], 'woocommerce-quick-order' ),
		'thumbnail_title' => esc_html( $block_settings['thumbnail_label'], 'woocommerce-quick-order' ),
		'product_title'   => esc_html( $block_settings['product_label'], 'woocommerce-quick-order' ),
		'quantity_title'  => esc_html( $block_settings['quantity_label'], 'woocommerce-quick-order' ),
		'price_title'     => esc_html( $block_settings['price_label'], 'woocommerce-quick-order' ),
		'actions_title'   => esc_html( $block_settings['action_label'], 'woocommerce-quick-order' ),
	);
} else {
	$options = array(
		'rfq'             => 0,
		'cat'             => 0,
		'csv_check'       => 0,
		'csv_text'        => __( 'Upload your order', 'woocommerce-quick-order' ),
		'thumbnail_title' => __( 'Thumbnail', 'woocommerce-quick-order' ),
		'product_title'   => __( 'Products', 'woocommerce-quick-order' ),
		'quantity_title'  => __( 'Quantity', 'woocommerce-quick-order' ),
		'price_title'     => __( 'Price', 'woocommerce-quick-order' ),
		'actions_title'   => __( 'Actions', 'woocommerce-quick-order' ),
	);
}

// if dynamically shortcode is working.
if ( 0 === $codeid && get_option( 'wqbo_settings' ) ) {
	$options = array_merge( $options, json_decode( get_option( 'wqbo_settings' ), true ) );
} elseif ( get_option( 'wqbo_settings_' . $codeid ) ) {
	$options = array_merge( $options, json_decode( get_option( 'wqbo_settings_' . $codeid ), true ) );
}
if ( $options['csv_check'] ) {
	?>
	<form method="post" id="wqbo-csv-order-form">
		<div class="wqbo-tbl-responsive">
			<h3><?php echo wp_kses_post( $options['csv_text'] ); ?></h3>
			<h4><?php esc_attr_e( 'Select a .CSV file here from your computer', 'woocommerce-quick-order' ); ?> </h4>
			<button class="get-driection" data-id="direction-modal" onclick="showPopup(this)"><?php esc_attr_e( 'Instructions', 'woocommerce-quick-order' ); ?></button> <br>
			<div id="direction-modal" class="direction-modal" style="display: none">
				<ul>
					<li><?php esc_attr_e( 'Enter Product Id/SKU in Column A', 'woocommerce-quick-order' ); ?></li>
					<li><?php esc_attr_e( 'Enter the quantities needed in Column B', 'woocommerce-quick-order' ); ?></li>
					<li><?php esc_attr_e( 'Please do not include any prefixes, dashes, or other punctuation in the item numbers. Save the file on your computer. CSV format (.csv) and click Upload.', 'woocommerce-quick-order' ); ?></li>
				</ul>
				<div class="place-image">
					<img src="<?php echo wp_kses_post( WQBO_PLUGIN_URL . 'public/img/csv.png' ); ?>">
				</div>
				<div class="close-button">
					<button type="button" name="close" class="close-popup" onclick="closePopup()"><?php esc_attr_e( 'Close', 'woocommerce-quick-order' ); ?></button>
					<button type="button" name="close" class="close-popup x-cl" onclick="closePopup()">&#9747;</button>
				</div>
			</div>
			<input type="hidden" name="_wpnonce" value="<?php echo wp_kses_post( wp_create_nonce( 'wqbo-quick-order' ) ); ?>"/>
			<div class="box">
			   <input type="file" name="csv_file" id="csv_file" class="inputfile inputfile-6">
			   <label for="csv_file">
				  <span></span> 
				  <strong>
					<?php esc_attr_e( 'Choose file…', 'woocommerce-quick-order' ); ?>
				  </strong>
			   </label>
			</div>
			<input type="submit" class="wqbo-quick-csv-order-submit" name="wqbo-quick-csv-order-submit" value="<?php esc_attr_e( 'Upload', 'woocommerce-quick-order' ); ?>">
			<div class="wqbo-csv-status"></div>
		</div>
	</form>
	<?php
}
?>
<form method="post" id="wqbo-order-form">
	<div class="wqbo-tbl-responsive">
		<table>
			<thead>
				<tr>
					<th><?php echo wp_kses_post( $options['thumbnail_title'] ); ?></td>
					<th><?php echo wp_kses_post( $options['product_title'] ); ?></th>
					<th><?php echo wp_kses_post( $options['quantity_title'] ); ?></th>
					<th><?php echo wp_kses_post( $options['price_title'] ); ?></th>
					<th><?php echo wp_kses_post( $options['actions_title'] ); ?></th>
				</tr>
			</thead>
			<tr>
				<td><div class="wqbo-thumb"><img src="<?php echo wp_kses_post( WQBO_PLUGIN_URL . 'public/img/no-image.png' ); ?>" date-src="<?php echo wp_kses_post( WQBO_PLUGIN_URL . 'public/img/no-image.png' ); ?>"/></div></td>
				
				<td>
					<input type="text" name="wqbo_product" class="form-control ctrl_enter" placeholder="<?php esc_attr_e( 'Search By SKU/Poduct Title', 'woocommerce-quick-order' ); ?>" data-type="simple" data-codeid='<?php echo wp_kses_post( $codeid ); ?>' id="wqbo_product_suggest" data-url="<?php echo wp_kses_post( home_url( $wp->request ) ); ?>" value="">
				</td>
				
				<td>
					<input type="number" min="1" name="wqbo_quantity" class="form-control ctrl_enter" placeholder="<?php esc_attr_e( 'Quantity', 'woocommerce-quick-order' ); ?>">
				</td>
				<td><div class="wqbo-price"></div></td>
				<td>
					<input type="hidden" name="_wpnonce" value='<?php echo wp_kses_post( wp_create_nonce( 'wqbo-quick-order' ) ); ?>' />
					<input type="hidden" name="block_settings" value='<?php echo isset( $block_settings ) ? wp_kses_post( json_encode( $block_settings ) ) : ''; ?>' />
					<button type="submit" name="wqbo-quick-order-submit" class="button wqbo-quick-order-submit"><?php esc_html_e( 'Add', 'woocommerce-quick-order' ); ?></button>
				</td>
			</tr>
		</table>
	</div><!--  /.wqbo-tbl-responsive  -->
</form>

<div id="wqbo-order-form" class="wqbo-bucket" style="margin-top: 10px;">
<?php
	return wc_get_template(
		'/frontend/quick-order-bucket.php',
		array(
			'codeid'          => $codeid,
			'bucket_products' => $bucket_products,
		),
		'woocommerce-quick-order',
		WQBO_TEMP_DIR
	);
	?>
</div>
