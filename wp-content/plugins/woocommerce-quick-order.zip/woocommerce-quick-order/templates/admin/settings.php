<?php
/**
 * Quick order Settings.
 *
 * @package B2B_Quick_Order/templates
 */

wp_enqueue_style( 'wqbo-settings-style' );
wp_enqueue_style( 'wqbo-select-woo-css' );

wp_enqueue_script( 'wqbo-select-woo-js' );
wp_enqueue_script( 'wqbo-admin-script' );

?>
<h1><?php esc_attr_e( 'Woocommerce Quick Order Settings', 'woocommerce-quick-order' ); ?></h1>
<?php /* translators: 1: plugin name */ echo sprintf( esc_attr__( 'Thank you for using %s .', 'woocommerce-quick-order' ), '<b>' . esc_attr__( 'WooCommerce Quick Order', 'woocommerce-quick-order' ) . '</b>' ); ?>
<br>
<div class="nav-tab-wrapper">
 <ul class="subsubsub">
	 <li>
		<a class="<?php echo ! filter_input( INPUT_GET, 'shortcodeid' ) ? 'current' : ''; ?>" href="?page=wqbo-quick-order-settings"> <?php esc_attr_e( 'Shortcode', 'woocommerce-quick-order' ); ?> </a>
	</li>|
	<?php
		$settings  = get_option( 'wqbo_shortcode_ids' );
		$shortcode = '';
	if ( $settings ) {
		$settings = json_decode( $settings, true );
		foreach ( $settings as $key => $value ) {
			if ( filter_input( INPUT_GET, 'shortcodeid' ) == $value ) {
				$shortcode = $value;
			}
			?>
			
			 <li>
				<a class="<?php echo ( filter_input( INPUT_GET, 'shortcodeid' ) == $value ) ? 'current' : ''; ?>" href="?page=wqbo-quick-order-settings&shortcodeid=<?php echo wp_kses_post( $value ); ?>"> 
									 <?php
										esc_attr_e( 'Shortcode', 'woocommerce-quick-order' );
										echo wp_kses_post( $value );
										?>
				</a>
			</li>|
			<?php
		}
	}
	?>
	
	<li>
	<form method="post" class="wqbo-settings-wrapper">
		<input type="hidden" name="shortcodeid" value="new" />
		<input type="hidden" name="_wpnonce" value="<?php echo wp_kses_post( wp_create_nonce( 'wqbo-settings' ) ); ?>" />
		<input type="hidden" name="csv_text" value="Upload your order" />
		<input type="hidden" name="thumbnail_title" value="Thumbnail" />
		<input type="hidden" name="product_title" value="Products" />
		<input type="hidden" name="quantity_title" value="Quantity" />
		<input type="hidden" name="price_title" value="Price" />
		<input type="hidden" name="actions_title" value="Actions" />
		<input type="submit" class="" name="wqbo_submit" value="<?php esc_attr_e( 'Add New Quick Order', 'woocommerce-quick-order' ); ?> " />
	</form>
	</li>
 </ul>
</div>

<?php
if ( wp_verify_nonce( filter_input( INPUT_POST, '_wpnonce' ), 'wqbo-settings' ) && filter_input( INPUT_POST, 'wqbo_submit' ) ) {
	?>
<div id="message" class="updated inline"><p><strong><?php esc_attr_e( 'Your settings have been saved.', 'woocommerce-quick-order' ); ?> </strong></p></div>
<?php } ?>

<p><?php esc_attr_e( 'Copy this short code to any page for the visibility of table.', 'woocommerce-quick-order' ); ?></p>
 <strong><?php esc_attr_e( 'Shortcode', 'woocommerce-quick-order' ); ?>: </strong><?php echo wp_kses_post( ! filter_input( INPUT_GET, 'shortcodeid' ) ? '<span>[wqbo_quick_order]</span>' : '<span>[wqbo_quick_order code-id=' . $shortcode . '] </span>' ); ?>
<?php
if ( filter_input( INPUT_GET, 'shortcodeid' ) ) {
	?>
<input type="hidden" class="admin_url" value="<?php echo esc_url_raw( admin_url() ); ?>">

	<?php
	$url = '<a class="delete_shortcode" data-id="' . wp_kses_post( filter_input( INPUT_GET, 'shortcodeid' ) ) . '" >' . esc_attr__( 'Delete', 'woocommerce-quick-order' ) . '</a>';
	?>
<p> <?php /* translators: %s: delete url */ echo sprintf( esc_attr__( 'Do you want to %s this shortcode ?', 'woocommerce-quick-order' ), wp_kses_post( $url ) ); ?></p>
<?php } ?>
<form method="post" class="wqbo-settings-wrapper">
	<?php
	$nonce = wp_create_nonce( 'wqbo-settings' );
	?>
	<h3><?php esc_attr_e( 'Exclude Categories', 'woocommerce-quick-order' ); ?> </h3>
	<p>
	<?php
	esc_attr_e( "Select categories of products you don't want to show in Quick Order form", 'woocommerce-quick-order' );
		echo wp_kses_post( wc_help_tip( __( 'To edit this order change the status back to "Pending"', 'woocommerce-quick-order' ) ) );
	?>
		</p>
	<div class="control-group">
		<label><?php esc_attr_e( 'Categories', 'woocommerce-quick-order' ); ?> </label>

		 <?php echo wp_kses_post( wc_help_tip( 'Selected Category Product will no be appear in Quick Search Result.' ) ); ?>
		<?php

		$selected = ( 0 === $cat ) ? $cat : array_map( 'intval', json_decode( $cat ) );
		require_once WQBO_ABSPATH . '/includes/class-custom-walker-categorydropdown.php';
		wp_dropdown_categories(
			array(
				'taxonomy'           => 'product_cat',
				'selected'           => $selected,
				'class'              => 'selectwoo',
				'multiple'           => true,
				'walker'             => new Custom_Walker_CategoryDropdown(),
				'hideesc_attr_empty' => 0,
			)
		);
		?>
	
	<h3> <?php esc_attr_e( 'CSV Import', 'woocommerce-quick-order' ); ?> </h3>
	<?php esc_attr_e( 'Enable a CSV upload option that lets users add to cart products in bulk from an excel file.', 'woocommerce-quick-order' ); ?>

	<br>
	<div class="control-group">
		<label><?php esc_attr_e( 'CSV Enable/Disable', 'woocommerce-quick-order' ); ?> </label>
		<input type="checkbox" name="csv_check" value="1" <?php echo 1 == $csv_check ? 'checked' : ''; ?>/>
	</div>
	<div class="control-group">
		<label><?php esc_attr_e( 'CSV Heading', 'woocommerce-quick-order' ); ?></label>
		<input type="text" name="csv_text" value="<?php echo wp_kses_post( $csv_text ); ?>" />
	</div>
	
	<h3> <?php esc_attr_e( 'Custom Headings', 'woocommerce-quick-order' ); ?></h3>
	<?php esc_attr_e( 'This lets you customize the headings of your Quick Order form.', 'woocommerce-quick-order' ); ?>

	<br>
	<div class="control-group">
		<label><?php esc_attr_e( 'Title for thumbnail fields', 'woocommerce-quick-order' ); ?></label>
		<input type="text" name="thumbnail_title" value="<?php echo wp_kses_post( $thumbnail_title ); ?>" />
	</div>
	<div class="control-group">
		<label><?php esc_attr_e( 'Title for product fields', 'woocommerce-quick-order' ); ?></label>
		<input type="text" name="product_title" value="<?php echo wp_kses_post( $product_title ); ?>" />
	</div>
	<div class="control-group">
		<label><?php esc_attr_e( 'Title for quantity fields', 'woocommerce-quick-order' ); ?></label>
		<input type="text" name="quantity_title" value="<?php echo wp_kses_post( $quantity_title ); ?>" />
	</div>
	<div class="control-group">
		<label><?php esc_attr_e( 'Title for price fields', 'woocommerce-quick-order' ); ?></label>
		<input type="text" name="price_title" value="<?php echo wp_kses_post( $price_title ); ?>" />
	</div>
	<div class="control-group">
		<label><?php esc_attr_e( 'Title for actions fields', 'woocommerce-quick-order' ); ?></label>
		<input type="text" name="actions_title" value="<?php echo wp_kses_post( $actions_title ); ?>" />
	</div>
	<br>
	<h2><?php esc_attr_e( 'B2B Ecommerce for Woocommerce', 'woocommerce-quick-order' ); ?></h1>
	<?php
	if ( in_array( 'b2b-ecommerce-for-woocommerce/b2b-ecommerce-for-woocommerce.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) ) {
		?>
	<p><?php esc_attr_e( 'You can add the following features on your Quick Order form. However, these features must be enabled on B2B eCommerce for WooCommerce settings', 'woocommerce-quick-order' ); ?></p>
		<?php
	} else {
		$url2 = '<a href="https://woocommerce.com/products/b2b-ecommerce-for-woocommerce/" target="blank"> Click here </a> ';
		?>
		<p><?php /* translators: %s: plugin url */ echo sprintf( esc_attr__( 'To enable these B2B features on your Quick Order form, B2B eCommerce plugin should be installed and activated. %s to download the plugin.', 'woocommerce-quick-order' ), wp_kses_post( $url2 ) ); ?></p>
		<?php
	}
	?>
		
	<br>
	<div class="control-group" >
		<label><?php esc_attr_e( 'Request For Quote', 'woocommerce-quick-order' ); ?></label>
		<?php
		if ( in_array( 'b2b-ecommerce-for-woocommerce/b2b-ecommerce-for-woocommerce.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) && 'yes' == get_option( 'codup-rfq_enable_rfq' ) ) {
			?>
			<input type="checkbox" name="rfq" value="1" <?php echo 1 == $rfq ? 'checked' : ''; ?> />
			<?php
		} else {
			?>
			<input type="checkbox" name="rfq" value="0" disabled="disabled" />
			<?php
		}
		?>
	</div>
	
	<br>
	<div class="control-group">
		<input type="hidden" name="shortcodeid" value="<?php echo filter_input( INPUT_GET, 'shortcodeid' ) ? filter_input( INPUT_GET, 'shortcodeid' ) : ''; ?>" />
		<input type="hidden" name="_wpnonce" value="<?php echo wp_kses_post( $nonce ); ?>" />
		<input type="submit" class="button button-primary" name="wqbo_submit" value="<?php esc_attr_e( 'Save Changes', 'woocommerce-quick-order' ); ?>" />
	</div>

</form>
