<?php
/**
 * Helper functions for getting product Info from woocommerce
 *
 * @package B2B_Quick_Order/templates
 */

/**
 * Get product image from id.
 *
 * @param int $product_id for getting product image.
 */
function get_product_image( $product_id ) {
	$img = WQBO_PLUGIN_URL . 'public/img/no-image.png';
	if ( get_the_post_thumbnail_url( $product_id ) ) {
		$img = get_the_post_thumbnail_url( $product_id );
	}
	return $img;
}

/**
 * Get product sku from id.
 *
 * @param int $product_id for getting product sku.
 */
function get_product_sku( $product_id ) {
	$sku     = false;
	$product = wc_get_product( $product_id );
	if ( $product->get_sku() ) {
		$sku = $product->get_sku();
	}
	return $sku;
}

/**
 * Get product title from id.
 *
 * @param int $product_id for getting product title.
 */
function get_product_title( $product_id ) {
	$product = wc_get_product( $product_id );
	if ( $product->is_type( 'variation' ) ) {
		$variations = $product->get_variation_attributes();
		if ( count( $variations ) > 2 ) {
			return $product->get_name() . ' - ' . implode( ', ', $variations );
		}
	}

	return $product->get_name();
}

/**
 * Get product sku from id.
 *
 * @param int $codeid for getting shortcode data.
 *
 * @return array.
 */
function get_shortcode_data( $codeid ) {
	if ( 0 == $codeid ) {
		return json_decode( get_option( 'wqbo_settings' ), true );
	} elseif ( get_option( 'wqbo_settings_' . $codeid ) ) {
		return json_decode( get_option( 'wqbo_settings_' . $codeid ), true );
	}
	return;
}

/**
 * Role Base Discount.
 *
 * @param object $product get discount product if discount were added.
 * @param int    $quantity discount will be depend on quantity.
 */
function role_base_discount( $product, $quantity ) {
	$user_id                   = get_current_user_id();
	$user_role                 = get_current_user_role_by_id( $user_id );
	$enable_role               = get_option( 'codup-role-based_enable_user_role' );
	$is_product_based_discount = get_option( 'codup-role-baseddiscount_type_product' );
	$is_global_based_discount  = get_option( 'codup-role-baseddiscount_type_global' );

	if ( 'yes' == $enable_role ) {
		if ( 'yes' == $is_product_based_discount ) {
			$discount = ( ! empty( get_product_based_discount( $product->get_ID(), $user_role[0] ) ) ) ? get_product_based_discount( $product->get_ID(), $user_role[0] ) : 0;

			if ( $product->is_type( 'variation' ) && is_array( $discount ) ) {
				if ( ! empty( $discount[ $product->get_ID() ] ) ) {
					$discount = $discount[ $product->get_ID() ];
				} else {
					$discount = 0;
				}
			}
		}

		if ( 'yes' == $is_global_based_discount ) {
			$discount = ( ! empty( get_globaly_setted_discount( $user_role[0] ) ) ) ? get_globaly_setted_discount( $user_role[0] ) : 0;
		}

		if ( 'yes' == $is_product_based_discount && 'yes' == $is_global_based_discount ) {
			$discount = ( ! empty( get_product_based_discount( $product->get_ID(), $user_role[0] ) ) ) ? get_product_based_discount( $product->get_ID(), $user_role[0] ) : get_globaly_setted_discount( $user_role[0] );

			if ( $product->is_type( 'variation' ) && is_array( $discount ) ) {
				if ( ! empty( $discount[ $product->get_ID() ] ) ) {
					$discount = $discount[ $product->get_ID() ];
				} else {
					$discount = get_globaly_setted_discount( $user_role[0] );
				}
			}
		}

		if ( $discount ) {
			$price         = ( ! empty( $product->get_regular_price() ) ) ? $product->get_regular_price() : $product->get_price();
			$price         = ( $price * $quantity );
			$updated_price = $price * $discount / 100;
			$updated_price = $price - $updated_price;

			return $updated_price;
		}
	}

	return false;
}
