<?php
/**
 * Contact Us Box on settings page.
 *
 * @package codup/templates
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'WQBO_Contact_Us' ) ) {

	/**
	 * Class Codup_Contact_Us
	 */
	class WQBO_Contact_Us {

		/**
		 * Function Construct
		 */
		public function __construct() {

			if ( isset( $_GET['page'] ) ) {
				if ( 'wqbo-quick-order-settings' == $_GET['page'] ) {

					add_action( 'admin_notices', array( $this, 'wqbo_contact_us' ), 9999 );

				}
			}
			add_filter( 'plugin_action_links_woocommerce-quick-order/codup-woocommerce-quick-order.php', array( $this, 'wqbo_settings_link' ) );
			add_filter( 'plugin_row_meta', array( $this, 'wqbo_support_and_faq_links' ), 10, 4 );
		}

		/**
		 * Function RFQ support and faq links
		 *
		 * @param array  $links_array Links Array.
		 * @param string $plugin_file_name Plugin File.
		 * @param array  $plugin_data Plugin Data.
		 * @param string $status Status.
		 */
		public function wqbo_support_and_faq_links( $links_array, $plugin_file_name, $plugin_data, $status ) {

			if ( 'woocommerce-quick-order/codup-woocommerce-quick-order.php' == $plugin_file_name ) {

				$url = '<a href="http://ecommerce.codup.io/support/tickets/new" target="_blank">' . esc_attr__( 'Get Support', 'woocommerce-quick-order' ) . '</a>';
				/* translators: 1: support link */
				$links_array[] = sprintf( esc_attr__( 'Having trouble in configuration? %s', 'woocommerce-quick-order' ), wp_kses_post( $url ) );
				$links_array[] = '<a href="mailto:woosupport@codup.io" target="_blank">' . esc_attr__( 'Email Us', 'woocommerce-quick-order' ) . '</a>';

			}
			return $links_array;
		}

		/**
		 * Function generate settings link.
		 *
		 * @param array $links_array Links Array.
		 */
		public function wqbo_settings_link( $links_array ) {

			array_unshift( $links_array, '<a href="' . site_url() . '/wp-admin/admin.php?page=wqbo-quick-order-settings">Settings</a>' );
			return $links_array;

		}

		/**
		 * Function Rfq contact us form.
		 */
		public function wqbo_contact_us() {
			?>
			<div class="notice notice-success codup-contact-us" style="position: absolute;right: 22px;top:220px;">
				<p>
					<?php
					$url  = '<a href="http://ecommerce.codup.io/support/tickets/new">' . esc_attr__( ' Contact us', 'woocommerce-quick-order' ) . '</a> ';
					$url2 = '<a href="mailto:woosupport@codup.io"> woosupport@codup.io </a> ';
					/* translators: 1: support url */
					echo sprintf( esc_attr__( 'Having trouble in configuration? %s for support', 'woocommerce-quick-order' ), wp_kses_post( $url ) );
					?>
				</p>
				<p>
					<?php /* translators: 1: support email */ echo sprintf( esc_attr__( 'Or email your query at %s ', 'woocommerce-quick-order' ), wp_kses_post( $url2 ) ); ?>
				</p>     
			</div>
			<div class="clear"></div>
			<?php
		}
	}

}
new WQBO_Contact_Us();
